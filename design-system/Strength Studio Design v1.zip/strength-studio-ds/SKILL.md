---
name: strength-studio-design
description: Use this skill to generate well-branded interfaces and assets for Strength Studio, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick Reference
- **Palette:** Ironstone #1F2225 · Canvas #F4F0EB · Ember #D15229 · Basalt #3D6A60
- **Type:** Manrope (body/UI) · Instrument Serif (display/campaign) · Special Gothic Expanded One (logotype only)
- **Voice:** Calm, specific, evidence-led. No motivational clichés. Adults to adults.
- **Radius:** 4/10/16px for elements, 999px pill for buttons
- **Rule:** Ember = training/action. Basalt = physio/recovery. Never swap.
