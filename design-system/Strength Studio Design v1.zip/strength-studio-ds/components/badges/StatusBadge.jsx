export function StatusBadge({
  children,
  variant = 'on-track',
  style: styleProp,
}) {
  const variants = {
    'on-track': {
      background: 'rgba(61, 106, 96, 0.10)',
      color: '#3D6A60',
      dotColor: '#3D6A60',
    },
    'recovery-week': {
      background: 'rgba(61, 106, 96, 0.10)',
      color: '#3D6A60',
      dotColor: '#3D6A60',
    },
    'physio-clearance': {
      background: 'rgba(61, 106, 96, 0.10)',
      color: '#3D6A60',
      dotColor: '#3D6A60',
    },
    'assessment-due': {
      background: 'rgba(209, 82, 41, 0.10)',
      color: '#D15229',
      dotColor: '#D15229',
    },
    'week-progress': {
      background: 'rgba(209, 82, 41, 0.10)',
      color: '#D15229',
      dotColor: '#D15229',
    },
    'active': {
      background: '#E6DED4',
      color: '#1F2225',
      dotColor: '#1F2225',
    },
    'completed': {
      background: '#F4F0EB',
      color: '#847B71',
      dotColor: '#B8B1A4',
    },
    'paused': {
      background: 'transparent',
      color: '#847B71',
      dotColor: null,
      border: '1px solid #DDD9D2',
    },
  };

  var v = variants[variant] || variants['on-track'];

  var base = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '6px',
    fontFamily: "'Manrope', system-ui, sans-serif",
    fontSize: '12px',
    fontWeight: 600,
    padding: '7px 14px',
    borderRadius: '999px',
    lineHeight: 1,
    background: v.background,
    color: v.color,
    border: v.border || 'none',
    ...styleProp,
  };

  return React.createElement('span', { style: base },
    v.dotColor && React.createElement('span', {
      style: {
        width: '7px',
        height: '7px',
        borderRadius: '50%',
        background: v.dotColor,
        flexShrink: 0,
      },
    }),
    children
  );
}
