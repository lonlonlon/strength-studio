/**
 * Strength Studio status badge — pill-shaped progress indicators for the coach dashboard.
 * Ember variants for training milestones, Basalt variants for physio milestones.
 *
 * @startingPoint section="Components" subtitle="Status badge (dashboard)" viewport="700x80"
 */
export interface StatusBadgeProps {
  children: React.ReactNode;
  /** Visual variant */
  variant?: 'on-track' | 'recovery-week' | 'physio-clearance' | 'assessment-due' | 'week-progress' | 'active' | 'completed' | 'paused';
  style?: React.CSSProperties;
}
export function StatusBadge(props: StatusBadgeProps): JSX.Element;
