# Badge

Status tag / label for Strength Studio. Used in card metadata, dashboard, and content tagging.

## Usage
```jsx
<Badge variant="training">Training</Badge>
<Badge variant="physio">Physio</Badge>
<Badge variant="neutral">Foundation</Badge>
<Badge variant="muted">Member only</Badge>
<Badge variant="status">On track</Badge>
<Badge variant="status-warning">Assessment due</Badge>
```

## Rules
- `training` — Ember tint background, Ember text. Training content.
- `physio` — Basalt tint background, Basalt text. Recovery content.
- `neutral` — Linen background. Package names, general labels.
- `muted` — Canvas background. Low-priority metadata.
- `status` / `status-warning` — with a leading dot indicator. Dashboard use.
