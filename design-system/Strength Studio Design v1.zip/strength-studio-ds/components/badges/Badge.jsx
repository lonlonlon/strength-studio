export function Badge({
  children,
  variant = 'training',
  style: styleProp,
}) {
  const variants = {
    training: {
      background: 'rgba(209, 82, 41, 0.10)',
      color: '#D15229',
    },
    physio: {
      background: 'rgba(61, 106, 96, 0.10)',
      color: '#3D6A60',
    },
    neutral: {
      background: '#E6DED4',
      color: '#1F2225',
    },
    muted: {
      background: '#F4F0EB',
      color: '#847B71',
    },
    status: {
      background: 'rgba(61, 106, 96, 0.10)',
      color: '#3D6A60',
    },
    'status-warning': {
      background: 'rgba(209, 82, 41, 0.10)',
      color: '#D15229',
    },
  };

  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '6px',
    fontFamily: "'Manrope', system-ui, sans-serif",
    fontSize: '11px',
    fontWeight: 600,
    letterSpacing: '0.12em',
    textTransform: 'uppercase',
    padding: '5px 10px',
    borderRadius: '6px',
    lineHeight: 1,
    ...variants[variant],
    ...styleProp,
  };

  const showDot = variant === 'status' || variant === 'status-warning';

  return React.createElement('span', { style: base },
    showDot && React.createElement('span', {
      style: {
        width: '6px',
        height: '6px',
        borderRadius: '50%',
        background: variants[variant].color,
      },
    }),
    children
  );
}
