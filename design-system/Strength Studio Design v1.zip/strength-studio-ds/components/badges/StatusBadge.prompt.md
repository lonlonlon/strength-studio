# StatusBadge

Pill-shaped progress indicator for Strength Studio's coach dashboard. Leading dot + label.

## Usage
```jsx
<StatusBadge variant="on-track">On track</StatusBadge>
<StatusBadge variant="assessment-due">Assessment due</StatusBadge>
<StatusBadge variant="week-progress">Week 6 of 8</StatusBadge>
<StatusBadge variant="active">Foundation · active</StatusBadge>
<StatusBadge variant="completed">Completed</StatusBadge>
<StatusBadge variant="paused">Paused</StatusBadge>
<StatusBadge variant="recovery-week">Recovery week</StatusBadge>
<StatusBadge variant="physio-clearance">Physio clearance</StatusBadge>
```

## Rules
- **Basalt family** (on-track, recovery-week, physio-clearance) — physio milestones
- **Ember family** (assessment-due, week-progress) — training milestones
- **Neutral** (active) — current programme status
- **Muted** (completed) — finished programmes
- **Ghost** (paused) — outline only, no dot
- Always pill radius (999px), never square tags
