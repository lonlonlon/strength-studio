/**
 * Strength Studio status badge / tag label.
 * Use `training` (Ember tint) for training content, `physio` (Basalt tint) for physio,
 * `neutral` (Linen) for packages, `muted` (Canvas) for member-only.
 *
 * @startingPoint section="Components" subtitle="Badge / tag label" viewport="700x80"
 */
export interface BadgeProps {
  children: React.ReactNode;
  /** Visual variant */
  variant?: 'training' | 'physio' | 'neutral' | 'muted' | 'status' | 'status-warning';
  style?: React.CSSProperties;
}
export function Badge(props: BadgeProps): JSX.Element;
