# DataTable

Data table for Strength Studio's coach dashboard. Member roster, session history, progress tracking.

## Usage
```jsx
<DataTable
  columns={[
    { label: 'Member', key: 'member', width: '2fr' },
    { label: 'Programme', key: 'programme', width: '1.4fr' },
    { label: 'Progress', key: 'progress', emphasis: true, numeric: true },
    { label: 'Status', key: 'status' },
  ]}
  rows={[
    {
      member: 'Eleanor Chen',
      programme: 'Foundation · 8 sessions',
      progress: '6 / 8',
      status: <StatusBadge variant="on-track">On track</StatusBadge>,
    },
  ]}
/>
```

## Rules
- Canvas (#F4F0EB) header row, Paper (#FFFFFF) body rows
- Linen (#E6DED4) dividers between rows
- Numeric columns use `tabular-nums` for alignment
- Status column accepts React elements (StatusBadge component)
- Avatar placeholders are 34px circles in Linen
