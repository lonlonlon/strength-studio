/**
 * Data table for Strength Studio's coach dashboard.
 * Canvas header row, Paper body, tabular-nums for numeric columns.
 *
 * @startingPoint section="Components" subtitle="Data table (dashboard)" viewport="700x280"
 */
export interface DataTableColumn {
  /** Column header label */
  label: string;
  /** Key to read from each row object */
  key: string;
  /** CSS grid width (e.g. '2fr', '100px'). Default '1fr' */
  width?: string;
  /** Bold + Ironstone text */
  emphasis?: boolean;
  /** Enable tabular-nums */
  numeric?: boolean;
}
export interface DataTableProps {
  columns: DataTableColumn[];
  /** Each row is an object keyed by column.key. Values can be strings or React elements. */
  rows: Array<Record<string, any>>;
  style?: React.CSSProperties;
}
export function DataTable(props: DataTableProps): JSX.Element;
