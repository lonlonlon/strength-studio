export function DataTable({
  columns = [],
  rows = [],
  style: styleProp,
}) {
  var container = {
    background: '#FFFFFF',
    borderRadius: '16px',
    overflow: 'hidden',
    boxShadow: '0 1px 0 #DDD9D2',
    fontFamily: "'Manrope', system-ui, sans-serif",
    ...styleProp,
  };

  var colTemplate = columns.map(function(c) { return c.width || '1fr'; }).join(' ');

  return React.createElement('div', { style: container },
    // Header
    React.createElement('div', {
      style: {
        display: 'grid',
        gridTemplateColumns: colTemplate,
        padding: '14px 24px',
        background: '#F4F0EB',
        borderBottom: '1px solid #DDD9D2',
        fontSize: '11px',
        letterSpacing: '0.1em',
        textTransform: 'uppercase',
        color: '#847B71',
        fontWeight: 600,
      },
    },
      ...columns.map(function(col, i) {
        return React.createElement('div', { key: i }, col.label);
      })
    ),
    // Rows
    ...rows.map(function(row, ri) {
      var isLast = ri === rows.length - 1;
      return React.createElement('div', {
        key: ri,
        style: {
          display: 'grid',
          gridTemplateColumns: colTemplate,
          padding: '16px 24px',
          borderBottom: !isLast ? '1px solid #E6DED4' : 'none',
          fontSize: '14px',
          alignItems: 'center',
        },
      },
        ...columns.map(function(col, ci) {
          var cell = row[col.key];
          if (typeof cell === 'object' && cell !== null && cell.$$typeof) {
            return React.createElement('div', { key: ci }, cell);
          }
          return React.createElement('div', {
            key: ci,
            style: {
              color: col.emphasis ? '#1F2225' : '#2E3330',
              fontWeight: col.emphasis ? 600 : 400,
              fontVariantNumeric: col.numeric ? 'tabular-nums' : undefined,
            },
          }, cell);
        })
      );
    })
  );
}
