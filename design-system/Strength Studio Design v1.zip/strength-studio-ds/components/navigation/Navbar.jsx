export function Navbar({
  logoSrc,
  links = [],
  ctaPrimary = 'Book Now',
  ctaSecondary = 'Join Us',
  onCtaPrimary,
  onCtaSecondary,
  variant = 'light',
  style: styleProp,
}) {
  var isLight = variant === 'light';

  var container = {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '16px 48px',
    fontFamily: "'Manrope', system-ui, sans-serif",
    background: isLight ? '#FFFFFF' : '#1F2225',
    borderBottom: isLight ? '1px solid #DDD9D2' : 'none',
    ...styleProp,
  };

  var logoStyle = {
    height: '28px',
    flexShrink: 0,
  };

  var navStyle = {
    display: 'flex',
    alignItems: 'center',
    gap: '32px',
  };

  var linkStyle = {
    fontSize: '14px',
    fontWeight: 500,
    color: isLight ? '#2E3330' : 'rgba(255,255,255,0.85)',
    textDecoration: 'none',
    cursor: 'pointer',
    transition: 'color 0.15s',
  };

  var actionsStyle = {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
  };

  var btnBase = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '9px 20px',
    borderRadius: '999px',
    fontSize: '14px',
    fontWeight: 600,
    fontFamily: "'Manrope', system-ui, sans-serif",
    cursor: 'pointer',
    transition: 'background 0.15s, color 0.15s',
  };

  var btnPrimaryStyle = Object.assign({}, btnBase, {
    background: isLight ? '#1F2225' : '#FFFFFF',
    color: isLight ? '#FFFFFF' : '#1F2225',
    border: 'none',
  });

  var btnSecondaryStyle = Object.assign({}, btnBase, {
    background: isLight ? '#E05A2D' : '#E05A2D',
    color: '#FFFFFF',
    border: 'none',
  });

  return React.createElement('nav', { style: container },
    /* Logo */
    logoSrc
      ? React.createElement('img', { src: logoSrc, alt: 'Strength Studio', style: logoStyle })
      : React.createElement('div', {
          style: {
            fontFamily: "'Special Gothic Expanded One', sans-serif",
            fontSize: '16px',
            lineHeight: 1,
            color: isLight ? '#1F2225' : '#FFFFFF',
            letterSpacing: '0.01em',
          },
        }, 'Strength Studio'),

    /* Links */
    React.createElement('div', { style: navStyle },
      ...links.map(function(link, i) {
        var label = typeof link === 'string' ? link : link.label;
        var href = typeof link === 'string' ? undefined : link.href;
        return React.createElement('a', { key: i, href: href, style: linkStyle }, label);
      })
    ),

    /* CTAs */
    React.createElement('div', { style: actionsStyle },
      ctaPrimary && React.createElement('button', { style: btnPrimaryStyle, onClick: onCtaPrimary }, ctaPrimary),
      ctaSecondary && React.createElement('button', { style: btnSecondaryStyle, onClick: onCtaSecondary }, ctaSecondary)
    )
  );
}
