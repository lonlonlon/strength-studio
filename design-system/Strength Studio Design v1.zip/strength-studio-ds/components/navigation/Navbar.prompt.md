# Navbar

Site navigation bar for Strength Studio. Two variants: light (Canvas/Paper on scroll) and dark (reversed over hero photography).

## Usage
```jsx
<Navbar
  logoSrc="assets/logo-color.svg"
  links={['Training', 'Physio', 'Trainers', 'Happenings', 'Contact']}
  ctaPrimary="Book Now"
  ctaSecondary="Join Us"
  variant="light"
/>
```

## Variants
- `light` — Paper background, Ironstone text, bordered bottom. Default scroll state.
- `dark` — Ironstone background, white text, no border. Floats over hero imagery.

## Rules
- Logo left, links centre, CTAs right
- Primary CTA: Ironstone fill (light) / white fill (dark)
- Secondary CTA: Ember fill, always
- Links: Manrope 500, 14px
