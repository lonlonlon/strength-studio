/**
 * Strength Studio navigation bar — light (Canvas/Paper scroll state) and dark (reversed over hero).
 * Logo left, nav links centre, dual CTA buttons right.
 *
 * @startingPoint section="Components" subtitle="Site navigation" viewport="700x60"
 */
export interface NavLink {
  label: string;
  href?: string;
}
export interface NavbarProps {
  logoSrc?: string;
  links?: Array<string | NavLink>;
  ctaPrimary?: string;
  ctaSecondary?: string;
  onCtaPrimary?: () => void;
  onCtaSecondary?: () => void;
  /** 'light' = Canvas/Paper bar; 'dark' = reversed on Ironstone */
  variant?: 'light' | 'dark';
  style?: React.CSSProperties;
}
export function Navbar(props: NavbarProps): JSX.Element;
