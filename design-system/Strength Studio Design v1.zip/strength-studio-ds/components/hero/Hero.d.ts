/**
 * Strength Studio homepage hero — Ironstone surface with display headline and dual CTAs.
 * Two-column grid: copy + actions on the left, image area on the right.
 *
 * @startingPoint section="Components" subtitle="Homepage hero" viewport="1200x560"
 */
export interface HeroProps {
  /** Small label above the headline, e.g. "77 @ East Coast · Opening 2026" */
  eyebrow?: string;
  headline: string;
  description?: string;
  ctaPrimary?: string;
  ctaSecondary?: string;
  onCtaPrimary?: () => void;
  onCtaSecondary?: () => void;
  /** Image src for the right column; if omitted, shows a labeled placeholder */
  imageSrc?: string;
  imagePlaceholder?: string;
  /** 'dark' = Ironstone (default homepage); 'light' = Canvas */
  variant?: 'dark' | 'light';
  style?: React.CSSProperties;
}
export function Hero(props: HeroProps): JSX.Element;
