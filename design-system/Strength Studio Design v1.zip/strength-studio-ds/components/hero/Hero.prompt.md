# Hero

Homepage hero section for Strength Studio. Ironstone surface, Instrument Serif display headline, dual CTAs, image placeholder on the right column.

## Usage
```jsx
<Hero
  eyebrow="77 @ East Coast · Opening 2026"
  headline="Where strength meets science."
  description="Premium strength training and physiotherapy for active adults. Evidence-based programming designed around your body, your goals, and your timeline."
  ctaPrimary="Book a movement assessment"
  ctaSecondary="Learn more"
/>
```

## Variants
- `dark` (default) — Ironstone background, Canvas text
- `light` — Canvas background, Ironstone text (for secondary hero contexts)

## Rules
- Display headline always Instrument Serif 400, never Manrope
- Eyebrow uses em-dash prefix and tracking 0.16em
- Primary CTA is always Ember; secondary is outline
- Right column shows a clearly-labeled photography placeholder until the real shot lands
- Sentence case for everything — never all caps headlines
