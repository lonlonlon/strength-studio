export function Hero({
  eyebrow,
  headline,
  description,
  ctaPrimary,
  ctaSecondary,
  onCtaPrimary,
  onCtaSecondary,
  imageSrc,
  imagePlaceholder = 'Placeholder · Hero photography to be added',
  variant = 'dark',
  style: styleProp,
}) {
  var isDark = variant === 'dark';

  var container = {
    background: isDark ? '#1F2225' : '#F4F0EB',
    color: isDark ? '#F4F0EB' : '#1F2225',
    fontFamily: "'Manrope', system-ui, sans-serif",
    padding: '72px 56px 56px',
    display: 'grid',
    gridTemplateColumns: '1.05fr 1fr',
    gap: '48px',
    alignItems: 'center',
    borderRadius: '16px',
    minHeight: '520px',
    ...styleProp,
  };

  var eyebrowStyle = {
    fontSize: '11px',
    fontWeight: 600,
    letterSpacing: '0.16em',
    textTransform: 'uppercase',
    color: isDark ? 'rgba(244,240,235,0.65)' : '#847B71',
    marginBottom: '28px',
    display: 'inline-flex',
    alignItems: 'center',
    gap: '10px',
  };

  var dashStyle = {
    display: 'inline-block',
    width: '18px',
    height: '1.5px',
    background: 'currentColor',
    flexShrink: 0,
  };

  var headlineStyle = {
    fontFamily: "'Instrument Serif', serif",
    fontSize: 'clamp(56px, 7vw, 96px)',
    lineHeight: 0.98,
    letterSpacing: '-0.015em',
    color: isDark ? '#F4F0EB' : '#1F2225',
    margin: '0 0 28px',
    maxWidth: '600px',
    fontWeight: 400,
  };

  var descStyle = {
    fontSize: '16px',
    lineHeight: 1.6,
    color: isDark ? 'rgba(244,240,235,0.78)' : '#847B71',
    maxWidth: '440px',
    marginBottom: '36px',
  };

  var ctaRow = {
    display: 'flex',
    flexWrap: 'wrap',
    gap: '12px',
  };

  var btnBase = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '14px 28px',
    borderRadius: '999px',
    fontSize: '15px',
    fontWeight: 600,
    fontFamily: "'Manrope', system-ui, sans-serif",
    cursor: 'pointer',
    transition: 'background 0.15s, color 0.15s',
  };

  var btnPrimaryStyle = Object.assign({}, btnBase, {
    background: '#E05A2D',
    color: '#FFFFFF',
    border: 'none',
  });

  var btnSecondaryStyle = Object.assign({}, btnBase, {
    background: 'transparent',
    color: isDark ? '#F4F0EB' : '#1F2225',
    border: isDark ? '1.5px solid rgba(244,240,235,0.4)' : '1.5px solid #1F2225',
  });

  var imageColumn = {
    position: 'relative',
    height: '100%',
    minHeight: '380px',
    borderRadius: '12px',
    border: isDark ? '1px dashed rgba(244,240,235,0.25)' : '1px dashed #DDD9D2',
    background: imageSrc ? 'transparent' : (isDark ? 'rgba(244,240,235,0.04)' : 'rgba(31,34,37,0.03)'),
    display: 'flex',
    alignItems: 'flex-end',
    justifyContent: 'flex-end',
    padding: '24px',
    overflow: 'hidden',
  };

  var imgStyle = {
    position: 'absolute',
    inset: 0,
    width: '100%',
    height: '100%',
    objectFit: 'cover',
  };

  var placeholderLabel = {
    fontSize: '10px',
    fontWeight: 600,
    letterSpacing: '0.14em',
    textTransform: 'uppercase',
    color: isDark ? 'rgba(244,240,235,0.5)' : '#847B71',
  };

  return React.createElement('section', { style: container },
    /* Left column */
    React.createElement('div', null,
      eyebrow && React.createElement('div', { style: eyebrowStyle },
        React.createElement('span', { style: dashStyle }),
        eyebrow
      ),
      React.createElement('h1', { style: headlineStyle }, headline),
      description && React.createElement('p', { style: descStyle }, description),
      (ctaPrimary || ctaSecondary) && React.createElement('div', { style: ctaRow },
        ctaPrimary && React.createElement('button', { style: btnPrimaryStyle, onClick: onCtaPrimary }, ctaPrimary),
        ctaSecondary && React.createElement('button', { style: btnSecondaryStyle, onClick: onCtaSecondary }, ctaSecondary)
      )
    ),
    /* Right column — image or placeholder */
    React.createElement('div', { style: imageColumn },
      imageSrc && React.createElement('img', { src: imageSrc, alt: '', style: imgStyle }),
      !imageSrc && React.createElement('span', { style: placeholderLabel }, imagePlaceholder)
    )
  );
}
