# DarkCard

Ironstone surface feature card for Strength Studio. Use to break visual rhythm between Canvas sections.

## Usage — CTA variant
```jsx
<DarkCard
  overline="Start here"
  headline="Every member starts with an assessment."
  body="60 minutes. One coach. A full movement screen."
  ctaLabel="Book a movement assessment"
/>
```

## Usage — Proof variant
```jsx
<DarkCard
  overline="Recovery outcomes"
  overlineColor="#3D6A60"
  headline="Programming built around evidence."
  headlineFont="sans"
  stats={[
    { value: '87', suffix: '%', label: 'Pain-reduced at week 8' },
    { value: '94', suffix: '%', label: '12-month retention' },
  ]}
/>
```

## Rules
- Max two dark cards in a row on any page
- CTA variant uses Instrument Serif headline + Ember button
- Proof variant uses Manrope bold headline + stat grid with Basalt accents for physio content
- Overline always prefixed with em dash (—)
