# PricingTier

Pricing comparison card for Strength Studio packages.

## Usage
```jsx
<PricingTier name="Foundation" sessions={8} rows={[
  { label: 'Duration', value: '~12 weeks' },
  { label: 'Assessment', value: 'Initial + Wk 8' },
  { label: 'Format', value: '1-to-1' },
  { label: 'Best for', value: 'Getting started' },
]} />

<PricingTier name="Momentum" sessions={16} featured badge="Recommended" rows={[
  { label: 'Duration', value: '~20 weeks' },
  { label: 'Assessment', value: 'Initial + Wk 8, 16' },
  { label: 'Format', value: '1-to-1' },
  { label: 'Best for', value: 'Building consistency' },
]} />
```

## Rules
- Only ONE tier is `featured` per comparison set
- Featured tier gets Ironstone bg + Ember CTA + optional floating badge
- Others get Paper bg + outline CTA
- Use alongside Solo/Duo/Crew chip selector
- Pricing says "Enquire" — no published S$ figures
