export function TrainerCard({
  name,
  role = 'Lead Trainer',
  imageSrc,
  experience,
  hours,
  tags = [],
  style: styleProp,
}) {
  var container = {
    fontFamily: "'Manrope', system-ui, sans-serif",
    borderRadius: '16px',
    overflow: 'hidden',
    background: '#FFFFFF',
    border: '1px solid #DDD9D2',
    ...styleProp,
  };

  var imageArea = {
    width: '100%',
    height: '260px',
    background: '#E6DED4',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    overflow: 'hidden',
  };

  var placeholderStyle = {
    fontSize: '11px',
    fontWeight: 600,
    letterSpacing: '0.12em',
    textTransform: 'uppercase',
    color: '#847B71',
    textAlign: 'center',
    lineHeight: 1.4,
  };

  var imgStyle = {
    width: '100%',
    height: '100%',
    objectFit: 'cover',
  };

  var infoStyle = {
    padding: '20px 24px',
  };

  var metaRow = {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: '8px',
  };

  var roleStyle = {
    fontSize: '11px',
    fontWeight: 600,
    letterSpacing: '0.12em',
    textTransform: 'uppercase',
    color: '#E05A2D',
  };

  var statsStyle = {
    fontSize: '11px',
    fontWeight: 500,
    color: '#847B71',
  };

  var nameStyle = {
    fontSize: '22px',
    fontWeight: 700,
    color: '#1F2225',
    marginBottom: '10px',
    lineHeight: 1.2,
  };

  var descStyle = {
    fontSize: '14px',
    lineHeight: 1.6,
    color: '#847B71',
    marginBottom: '14px',
  };

  var tagsRow = {
    display: 'flex',
    flexWrap: 'wrap',
    gap: '6px',
  };

  var tagStyle = {
    fontSize: '11px',
    fontWeight: 600,
    letterSpacing: '0.06em',
    textTransform: 'uppercase',
    padding: '5px 12px',
    borderRadius: '999px',
    background: '#F4F0EB',
    color: '#2E3330',
    border: '1px solid #DDD9D2',
  };

  var statsText = [];
  if (experience) statsText.push(experience);
  if (hours) statsText.push(hours);

  return React.createElement('div', { style: container },
    React.createElement('div', { style: imageArea },
      imageSrc
        ? React.createElement('img', { src: imageSrc, alt: name, style: imgStyle })
        : React.createElement('div', { style: placeholderStyle }, 'PLACEHOLDER · TRAINER PORTRAIT\nPortrait · 5:3 · environmental shot in-studio')
    ),
    React.createElement('div', { style: infoStyle },
      React.createElement('div', { style: metaRow },
        React.createElement('span', { style: roleStyle }, role),
        statsText.length > 0 && React.createElement('span', { style: statsStyle }, statsText.join(' · '))
      ),
      React.createElement('div', { style: nameStyle }, name),
      tags.length > 0 && React.createElement('div', { style: tagsRow },
        ...tags.map(function(tag, i) {
          return React.createElement('span', { key: i, style: tagStyle }, tag);
        })
      )
    )
  );
}
