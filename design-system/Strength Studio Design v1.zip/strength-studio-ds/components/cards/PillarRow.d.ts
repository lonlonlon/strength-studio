/**
 * Horizontal pillar row — index + title on the left, description on the right.
 * Use within a vertical stack on Canvas/Paper sections. For the boxed Linen card variant, use PillarCard.
 *
 * @startingPoint section="Components" subtitle="Horizontal brand pillar row" viewport="700x130"
 */
export interface PillarRowProps {
  /** Numeric index, zero-padded to two digits */
  index?: number;
  /** Uppercase label after the index; defaults to title.toUpperCase() */
  label?: string;
  title: string;
  description?: string;
  style?: React.CSSProperties;
}
export function PillarRow(props: PillarRowProps): JSX.Element;
