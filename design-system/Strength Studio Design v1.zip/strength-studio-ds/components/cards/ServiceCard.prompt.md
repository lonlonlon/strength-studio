# ServiceCard

Clinical spec-sheet card for displaying service details. Used on the /training page.

## Usage
```jsx
<ServiceCard
  index={2}
  title="Strength Programming"
  subtitle="Foundation block — 8 sessions across 12 weeks."
  accepting={true}
  rows={[
    { label: 'Format', value: 'Solo · Duo · Crew' },
    { label: 'Sessions per week', value: '2 — 3' },
    { label: 'Coach', value: 'Bernard Sim, Lead Trainer' },
    { label: 'Re-assessment', value: 'Week 04 & 08' },
    { label: 'From', value: 'S$ on enquiry', bold: true },
  ]}
  ctaLabel="Request a consultation"
/>
```

## Notes
- Always uses Ember CTA button
- Rows use hairline Linen dividers
- "Now accepting" status dot appears when `accepting` is true
