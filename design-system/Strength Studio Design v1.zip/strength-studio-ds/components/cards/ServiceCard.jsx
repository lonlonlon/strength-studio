export function ServiceCard({
  index,
  title,
  subtitle,
  rows = [],
  ctaLabel = 'Request a consultation',
  onCta,
  accepting = true,
  style: styleProp,
}) {
  const card = {
    background: '#FFFFFF',
    borderRadius: '16px',
    padding: '32px 32px 28px',
    boxShadow: '0 1px 0 #DDD9D2',
    fontFamily: "'Manrope', system-ui, sans-serif",
    ...styleProp,
  };

  return React.createElement('div', { style: card },
    // Header
    React.createElement('div', {
      style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' },
    },
      React.createElement('div', {
        style: { fontSize: '11px', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#847B71', fontWeight: 600 },
      }, 'Service spec' + (index ? ' · ' + String(index).padStart(2, '0') : '')),
      accepting && React.createElement('div', {
        style: { display: 'flex', alignItems: 'center', gap: '6px' },
      },
        React.createElement('span', {
          style: { width: '6px', height: '6px', borderRadius: '50%', background: '#D15229' },
        }),
        React.createElement('span', {
          style: { fontSize: '11px', letterSpacing: '0.1em', textTransform: 'uppercase', color: '#D15229', fontWeight: 600 },
        }, 'Now accepting')
      )
    ),
    // Title
    React.createElement('div', {
      style: { fontSize: '28px', lineHeight: '1.1', letterSpacing: '-0.025em', fontWeight: 700, marginBottom: '6px', color: '#1F2225' },
    }, title),
    // Subtitle
    subtitle && React.createElement('div', {
      style: { fontSize: '14px', color: '#847B71', marginBottom: '24px' },
    }, subtitle),
    // Spec rows
    rows.length > 0 && React.createElement('div', null,
      ...rows.map(function(row, i) {
        return React.createElement('div', {
          key: i,
          style: {
            display: 'flex',
            justifyContent: 'space-between',
            padding: '14px 0',
            borderTop: '1px solid #E6DED4',
            borderBottom: i === rows.length - 1 ? '1px solid #E6DED4' : 'none',
            fontSize: '13px',
          },
        },
          React.createElement('span', { style: { color: '#847B71' } }, row.label),
          React.createElement('span', {
            style: { color: '#1F2225', fontWeight: row.bold ? 700 : 600, fontVariantNumeric: 'tabular-nums' },
          }, row.value)
        );
      })
    ),
    // CTA
    ctaLabel && React.createElement('button', {
      style: {
        marginTop: '24px',
        width: '100%',
        fontFamily: "'Manrope', system-ui, sans-serif",
        fontSize: '14px',
        fontWeight: 600,
        padding: '14px 24px',
        borderRadius: '999px',
        background: '#D15229',
        color: '#FFFFFF',
        border: 'none',
        cursor: 'pointer',
      },
      onClick: onCta,
    }, ctaLabel)
  );
}
