/**
 * Linen surface pillar card with numbered index — used for brand pillars and value propositions.
 * 16px radius, index in upper area as "01 / TITLE" label.
 *
 * @startingPoint section="Components" subtitle="Brand pillar card" viewport="700x180"
 */
export interface PillarCardProps {
  /** Numeric index, zero-padded to two digits */
  index?: number;
  title: string;
  description?: string;
  style?: React.CSSProperties;
}
export function PillarCard(props: PillarCardProps): JSX.Element;
