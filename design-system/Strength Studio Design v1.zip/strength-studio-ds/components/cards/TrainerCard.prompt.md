# TrainerCard

Trainer portrait card for the /trainers page and homepage proof section.

## Usage
```jsx
<TrainerCard
  name="Bernard Sim"
  role="Lead Trainer"
  experience="8+ yrs"
  hours="10,000+ hrs"
  tags={['Pre/Post-natal', 'Strength & Toning']}
/>
```

## Anatomy
1. Portrait image area (5:3 ratio) — Linen placeholder if no image
2. Role label — Ember, uppercase, 11px
3. Experience/hours stats — Flint, right-aligned
4. Name — Manrope 700, 22px
5. Specialty tags — pill chips, Canvas fill

## Rules
- Paper background, Border edge, 16px radius
- Image should be environmental, in-studio
- Role label always in Ember
