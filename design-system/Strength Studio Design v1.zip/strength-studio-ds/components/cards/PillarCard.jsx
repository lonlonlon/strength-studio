export function PillarCard({
  index,
  title,
  description,
  style: styleProp,
}) {
  var container = {
    background: '#E6DED4',
    borderRadius: '16px',
    padding: '28px 24px',
    fontFamily: "'Manrope', system-ui, sans-serif",
    display: 'flex',
    flexDirection: 'column',
    gap: '12px',
    minHeight: '160px',
    ...styleProp,
  };

  var indexStyle = {
    fontSize: '11px',
    fontWeight: 600,
    letterSpacing: '0.14em',
    textTransform: 'uppercase',
    color: '#847B71',
  };

  var titleStyle = {
    fontSize: '18px',
    fontWeight: 700,
    color: '#1F2225',
    lineHeight: 1.3,
  };

  var descStyle = {
    fontSize: '14px',
    lineHeight: 1.6,
    color: '#847B71',
  };

  var formattedIndex = index != null
    ? (index < 10 ? '0' + index : '' + index)
    : null;

  return React.createElement('div', { style: container },
    formattedIndex && React.createElement('div', { style: indexStyle },
      formattedIndex + ' / ' + (title ? title.toUpperCase() : '')
    ),
    React.createElement('div', { style: titleStyle }, title),
    description && React.createElement('div', { style: descStyle }, description)
  );
}
