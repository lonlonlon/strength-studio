export function PillarRow({
  index,
  label,
  title,
  description,
  style: styleProp,
}) {
  var container = {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '24px',
    padding: '24px 0',
    borderTop: '1px solid #DDD9D2',
    fontFamily: "'Manrope', system-ui, sans-serif",
    ...styleProp,
  };

  var leftCol = {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
  };

  var indexLabel = {
    fontSize: '11px',
    fontWeight: 600,
    letterSpacing: '0.14em',
    textTransform: 'uppercase',
    color: '#847B71',
    display: 'flex',
    gap: '6px',
  };

  var indexNum = {
    color: '#1F2225',
  };

  var titleStyle = {
    fontSize: '18px',
    fontWeight: 700,
    color: '#1F2225',
    lineHeight: 1.3,
    margin: 0,
  };

  var descStyle = {
    fontSize: '14px',
    lineHeight: 1.65,
    color: '#847B71',
    margin: 0,
  };

  var formattedIndex = index != null
    ? (index < 10 ? '0' + index : '' + index)
    : null;

  return React.createElement('div', { style: container },
    React.createElement('div', { style: leftCol },
      formattedIndex && React.createElement('div', { style: indexLabel },
        React.createElement('span', { style: indexNum }, formattedIndex),
        React.createElement('span', null, '/'),
        React.createElement('span', null, (label || title || '').toUpperCase())
      ),
      React.createElement('h3', { style: titleStyle }, title)
    ),
    React.createElement('div', null,
      description && React.createElement('p', { style: descStyle }, description)
    )
  );
}
