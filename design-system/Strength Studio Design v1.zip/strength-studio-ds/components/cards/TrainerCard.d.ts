/**
 * Trainer portrait card for /trainers page and homepage proof section.
 * Image area with fallback placeholder, role label, name, and specialty tags.
 *
 * @startingPoint section="Components" subtitle="Trainer profile card" viewport="360x440"
 */
export interface TrainerCardProps {
  name: string;
  role?: string;
  imageSrc?: string;
  experience?: string;
  hours?: string;
  tags?: string[];
  style?: React.CSSProperties;
}
export function TrainerCard(props: TrainerCardProps): JSX.Element;
