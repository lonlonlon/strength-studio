# PillarRow

Horizontal pillar row pattern for the homepage About section.

## Usage
```jsx
<PillarRow
  index={1}
  label="Personalised"
  title="No cookie-cutter programs."
  description="Every plan is built around the assessment — your history, mobility, and goals."
/>
```

## Anatomy
- Left column: "01 / PERSONALISED" label above the title (Manrope 700, 18px)
- Right column: description body in Flint
- Top hairline border between rows
- No background — sits directly on Canvas/Paper

## When to use
- Homepage About section (3–4 stacked pillars)
- Use **PillarCard** instead when you need a boxed Linen surface treatment
