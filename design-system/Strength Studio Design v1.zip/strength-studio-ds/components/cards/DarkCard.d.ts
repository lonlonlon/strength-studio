/**
 * Ironstone surface feature card for breaking rhythm between Canvas sections.
 * Two modes: CTA card (display headline + button) or proof card (stat grid).
 *
 * @startingPoint section="Components" subtitle="Dark feature card" viewport="700x320"
 */
export interface DarkCardProps {
  /** Overline text (rendered after an em dash) */
  overline?: string;
  /** Overline color — Ember for training, Basalt for physio */
  overlineColor?: string;
  headline?: string;
  /** 'display' uses Instrument Serif; 'sans' uses Manrope bold */
  headlineFont?: 'display' | 'sans';
  body?: string;
  /** Stat grid shown below a top border */
  stats?: Array<{ value: string; suffix?: string; label: string }>;
  ctaLabel?: string;
  onCta?: () => void;
  style?: React.CSSProperties;
}
export function DarkCard(props: DarkCardProps): JSX.Element;
