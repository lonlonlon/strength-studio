export function DarkCard({
  overline,
  overlineColor = '#D15229',
  headline,
  headlineFont = 'display',
  body,
  stats,
  ctaLabel,
  onCta,
  style: styleProp,
}) {
  var card = {
    background: '#1F2225',
    borderRadius: '16px',
    padding: '40px 36px',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-between',
    minHeight: '280px',
    fontFamily: "'Manrope', system-ui, sans-serif",
    ...styleProp,
  };

  var headlineStyle = headlineFont === 'display'
    ? { fontFamily: "'Instrument Serif', serif", fontSize: '40px', lineHeight: '1.05', letterSpacing: '-0.02em', fontWeight: 400, color: '#F4F0EB', marginBottom: '16px' }
    : { fontSize: '28px', lineHeight: '1.15', letterSpacing: '-0.02em', fontWeight: 700, color: '#F4F0EB', marginBottom: '20px' };

  return React.createElement('div', { style: card },
    React.createElement('div', null,
      overline && React.createElement('div', {
        style: { fontSize: '11px', letterSpacing: '0.14em', textTransform: 'uppercase', color: overlineColor, fontWeight: 600, marginBottom: '18px' },
      }, '— ' + overline),
      headline && React.createElement('div', { style: headlineStyle }, headline),
      body && React.createElement('div', {
        style: { fontSize: '14px', lineHeight: '1.6', color: '#B8B1A4', maxWidth: '400px' },
      }, body)
    ),
    stats && React.createElement('div', {
      style: { display: 'grid', gridTemplateColumns: 'repeat(' + stats.length + ', 1fr)', gap: '20px', paddingTop: '24px', borderTop: '1px solid #2E3330', marginTop: '28px' },
    },
      ...stats.map(function(stat, i) {
        return React.createElement('div', { key: i },
          React.createElement('div', {
            style: { fontSize: '36px', lineHeight: 1, letterSpacing: '-0.03em', fontWeight: 700, color: '#F4F0EB' },
          },
            stat.value,
            stat.suffix && React.createElement('span', { style: { color: overlineColor } }, stat.suffix)
          ),
          React.createElement('div', {
            style: { fontSize: '11px', letterSpacing: '0.1em', textTransform: 'uppercase', color: '#847B71', marginTop: '8px', fontWeight: 600 },
          }, stat.label)
        );
      })
    ),
    ctaLabel && React.createElement('div', { style: { marginTop: '28px' } },
      React.createElement('button', {
        style: {
          fontFamily: "'Manrope', system-ui, sans-serif",
          fontSize: '14px',
          fontWeight: 600,
          padding: '14px 24px',
          borderRadius: '999px',
          background: '#D15229',
          color: '#FFFFFF',
          border: 'none',
          cursor: 'pointer',
        },
        onClick: onCta,
      }, ctaLabel)
    )
  );
}
