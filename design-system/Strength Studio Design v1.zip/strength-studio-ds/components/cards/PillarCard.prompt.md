# PillarCard

Linen surface card for brand pillars and value propositions on the Strength Studio marketing site.

## Usage
```jsx
<PillarCard
  index={1}
  title="Personalised"
  description="Every plan is built around the assessment — your history, your mobility, your goals."
/>
```

## Anatomy
1. Numbered index label — "01 / PERSONALISED" in uppercase, Flint colour
2. Title — Manrope 700, 18px, Ironstone
3. Description — Manrope 400, 14px, Flint

## Rules
- Always Linen (#E6DED4) background
- 16px border radius
- Index is zero-padded (01, 02, 03)
- Used in groups of 3–4 in a grid row
