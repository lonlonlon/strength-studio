/**
 * Clinical spec-sheet service card for Strength Studio.
 * Displays service details in a key-value row layout with an optional CTA.
 *
 * @startingPoint section="Components" subtitle="Service spec card" viewport="400x420"
 */
export interface ServiceCardProps {
  /** Service number (e.g. 1, 2, 3) */
  index?: number;
  title: string;
  subtitle?: string;
  /** Key-value spec rows */
  rows?: Array<{ label: string; value: string; bold?: boolean }>;
  ctaLabel?: string;
  onCta?: () => void;
  /** Show "Now accepting" status dot */
  accepting?: boolean;
  style?: React.CSSProperties;
}
export function ServiceCard(props: ServiceCardProps): JSX.Element;
