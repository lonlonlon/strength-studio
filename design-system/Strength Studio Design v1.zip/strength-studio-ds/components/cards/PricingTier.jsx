export function PricingTier({
  name,
  sessions,
  rows = [],
  featured = false,
  badge,
  ctaLabel = 'Enquire',
  onCta,
  style: styleProp,
}) {
  var card = {
    background: featured ? '#1F2225' : '#FFFFFF',
    borderRadius: '16px',
    padding: '32px 28px 28px',
    display: 'flex',
    flexDirection: 'column',
    fontFamily: "'Manrope', system-ui, sans-serif",
    position: 'relative',
    boxShadow: featured ? 'none' : '0 1px 0 #DDD9D2',
    ...styleProp,
  };

  var textPrimary = featured ? '#F4F0EB' : '#1F2225';
  var textSecondary = '#847B71';
  var dividerColor = featured ? '#2E3330' : '#E6DED4';
  var nameColor = featured ? '#D15229' : '#847B71';

  return React.createElement('div', { style: card },
    badge && React.createElement('div', {
      style: {
        position: 'absolute',
        top: '-10px',
        right: '20px',
        fontSize: '10px',
        fontWeight: 600,
        letterSpacing: '0.14em',
        textTransform: 'uppercase',
        color: '#FFFFFF',
        background: '#D15229',
        padding: '5px 12px',
        borderRadius: '999px',
      },
    }, badge),
    React.createElement('div', {
      style: { fontSize: '11px', letterSpacing: '0.14em', textTransform: 'uppercase', color: nameColor, fontWeight: 600, marginBottom: '14px' },
    }, name),
    React.createElement('div', {
      style: { fontSize: '36px', lineHeight: 1, letterSpacing: '-0.03em', fontWeight: 700, color: textPrimary, marginBottom: '4px' },
    }, String(sessions)),
    React.createElement('div', {
      style: { fontSize: '13px', color: textSecondary, marginBottom: '24px' },
    }, 'sessions'),
    React.createElement('div', { style: { flex: 1 } },
      ...rows.map(function(row, i) {
        return React.createElement('div', {
          key: i,
          style: {
            display: 'flex',
            justifyContent: 'space-between',
            padding: '12px 0',
            borderTop: '1px solid ' + dividerColor,
            borderBottom: i === rows.length - 1 ? '1px solid ' + dividerColor : 'none',
            fontSize: '13px',
          },
        },
          React.createElement('span', { style: { color: textSecondary } }, row.label),
          React.createElement('span', { style: { color: textPrimary, fontWeight: 600 } }, row.value)
        );
      })
    ),
    React.createElement('button', {
      style: {
        marginTop: '24px',
        width: '100%',
        fontFamily: "'Manrope', system-ui, sans-serif",
        fontSize: '14px',
        fontWeight: 600,
        padding: '13px 24px',
        borderRadius: '999px',
        background: featured ? '#D15229' : 'transparent',
        color: featured ? '#FFFFFF' : '#1F2225',
        border: featured ? 'none' : '1.5px solid #1F2225',
        cursor: 'pointer',
      },
      onClick: onCta,
    }, ctaLabel)
  );
}
