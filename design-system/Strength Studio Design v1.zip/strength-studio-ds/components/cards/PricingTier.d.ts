/**
 * Pricing tier card for Strength Studio's /training page.
 * Featured tier gets Ironstone surface + Ember CTA; others stay on Paper with outline CTAs.
 *
 * @startingPoint section="Components" subtitle="Pricing tier card" viewport="700x380"
 */
export interface PricingTierProps {
  /** Package name (Foundation, Momentum, Mastery) */
  name: string;
  /** Session count */
  sessions: number;
  /** Spec rows */
  rows?: Array<{ label: string; value: string }>;
  /** Use Ironstone surface + Ember CTA */
  featured?: boolean;
  /** Floating badge text (e.g. "Recommended") */
  badge?: string;
  ctaLabel?: string;
  onCta?: () => void;
  style?: React.CSSProperties;
}
export function PricingTier(props: PricingTierProps): JSX.Element;
