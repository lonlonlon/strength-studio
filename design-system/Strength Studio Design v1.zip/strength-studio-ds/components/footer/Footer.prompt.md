# Footer

Full-width Ironstone footer for Strength Studio marketing site.

## Usage
```jsx
<Footer
  logoSrc="assets/logo-white.svg"
  description="A specialised fitness studio combining evidence-based strength training with physiotherapy expertise."
  address="77 @ East Coast, Singapore"
  trainingLinks={['Solo Track', 'Duo Track', 'Crew Track', 'Movement Assessment', 'Programming Only']}
  studioLinks={['About', 'Our coaches', 'Physiotherapy', 'Happenings', 'Contact']}
  connectLinks={['Instagram', 'WhatsApp', 'Email']}
/>
```

## Anatomy
1. Four-column grid: brand + description, Training (Ember overline), Studio (Basalt overline), Connect
2. Oversized wordmark in Special Gothic Expanded at ~96px in Charcoal — visible but not dominant
3. Bottom bar with legal text and Privacy/Terms links

## Rules
- Always full-width, Ironstone surface
- Overline colors: Training = Ember, Studio = Basalt, Connect = Flint
- Wordmark in sentence case, never all caps
- Legal references JSF Transformative Pte Ltd
