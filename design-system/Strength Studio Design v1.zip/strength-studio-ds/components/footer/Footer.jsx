export function Footer({
  logoSrc,
  description,
  address,
  trainingLinks = [],
  studioLinks = [],
  connectLinks = [],
  legal = '© 2026 JSF Transformative Pte Ltd',
  style: styleProp,
}) {
  var container = {
    background: '#1F2225',
    fontFamily: "'Manrope', system-ui, sans-serif",
    ...styleProp,
  };

  var linkStyle = {
    fontSize: '14px',
    color: '#B8B1A4',
    cursor: 'pointer',
  };

  function renderColumn(title, color, links) {
    return React.createElement('div', null,
      React.createElement('div', {
        style: { fontSize: '11px', letterSpacing: '0.14em', textTransform: 'uppercase', color: color, fontWeight: 600, marginBottom: '18px' },
      }, title),
      React.createElement('div', {
        style: { display: 'flex', flexDirection: 'column', gap: '12px' },
      },
        ...links.map(function(link, i) {
          return React.createElement('span', { key: i, style: linkStyle }, typeof link === 'string' ? link : link.label);
        })
      )
    );
  }

  return React.createElement('div', { style: container },
    React.createElement('div', {
      style: { padding: '56px 48px 40px' },
    },
      React.createElement('div', {
        style: { display: 'grid', gridTemplateColumns: '1.6fr 1fr 1fr 1fr', gap: '48px', marginBottom: '48px' },
      },
        React.createElement('div', null,
          logoSrc && React.createElement('img', {
            src: logoSrc,
            alt: 'Strength Studio',
            style: { height: '24px', marginBottom: '20px' },
          }),
          description && React.createElement('div', {
            style: { fontSize: '14px', lineHeight: '1.6', color: '#B8B1A4', maxWidth: '280px', marginBottom: '20px' },
          }, description),
          address && React.createElement('div', {
            style: { fontSize: '13px', color: '#847B71' },
          }, address)
        ),
        renderColumn('Training', '#D15229', trainingLinks),
        renderColumn('Studio', '#3D6A60', studioLinks),
        renderColumn('Connect', '#847B71', connectLinks)
      ),
      React.createElement('div', {
        style: {
          fontFamily: "'Special Gothic Expanded One', sans-serif",
          fontSize: '96px',
          lineHeight: 1,
          color: '#2E3330',
          letterSpacing: '0.02em',
          overflow: 'hidden',
          whiteSpace: 'nowrap',
        },
      }, 'Strength Studio')
    ),
    React.createElement('div', {
      style: {
        padding: '20px 48px',
        borderTop: '1px solid #2E3330',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
      },
    },
      React.createElement('div', {
        style: { fontSize: '12px', color: '#847B71' },
      }, legal),
      React.createElement('div', {
        style: { display: 'flex', gap: '24px', fontSize: '12px', color: '#847B71' },
      },
        React.createElement('span', null, 'Privacy'),
        React.createElement('span', null, 'Terms')
      )
    )
  );
}
