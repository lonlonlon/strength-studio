/**
 * Strength Studio site footer — Ironstone surface with oversized wordmark.
 * Four-column layout: brand, Training (Ember overline), Studio (Basalt overline), Connect.
 *
 * @startingPoint section="Components" subtitle="Site footer" viewport="700x300"
 */
export interface FooterLink {
  label: string;
  href?: string;
}
export interface FooterProps {
  logoSrc?: string;
  description?: string;
  address?: string;
  trainingLinks?: Array<string | FooterLink>;
  studioLinks?: Array<string | FooterLink>;
  connectLinks?: Array<string | FooterLink>;
  legal?: string;
  style?: React.CSSProperties;
}
export function Footer(props: FooterProps): JSX.Element;
