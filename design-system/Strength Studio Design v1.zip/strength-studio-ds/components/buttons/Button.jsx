export function Button({
  children,
  variant = 'primary',
  size = 'md',
  onClick,
  disabled = false,
  fullWidth = false,
  style: styleProp,
  ...rest
}) {
  const base = {
    fontFamily: "'Manrope', system-ui, sans-serif",
    fontWeight: 600,
    letterSpacing: '-0.005em',
    border: 'none',
    cursor: disabled ? 'default' : 'pointer',
    opacity: disabled ? 0.5 : 1,
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    transition: 'background 0.15s, border-color 0.15s, opacity 0.15s',
    borderRadius: '999px',
    width: fullWidth ? '100%' : undefined,
  };

  const sizes = {
    sm: { fontSize: '13px', padding: '9px 16px' },
    md: { fontSize: '14px', padding: '14px 24px' },
    lg: { fontSize: '16px', padding: '16px 28px' },
  };

  const variants = {
    primary: {
      background: '#D15229',
      color: '#FFFFFF',
    },
    secondary: {
      background: '#1F2225',
      color: '#FFFFFF',
    },
    outline: {
      background: 'transparent',
      color: '#1F2225',
      border: '1.5px solid #1F2225',
    },
    ghost: {
      background: 'transparent',
      color: '#1F2225',
      border: '1.5px solid #DDD9D2',
    },
    physio: {
      background: '#3D6A60',
      color: '#FFFFFF',
    },
    'physio-outline': {
      background: 'transparent',
      color: '#3D6A60',
      border: '1.5px solid #3D6A60',
    },
    chip: {
      background: 'transparent',
      color: '#1F2225',
      border: '1px solid #DDD9D2',
      fontSize: '13px',
      padding: '9px 16px',
      fontWeight: 500,
    },
    'chip-active': {
      background: '#1F2225',
      color: '#FFFFFF',
      border: '1px solid #1F2225',
      fontSize: '13px',
      padding: '9px 16px',
      fontWeight: 500,
    },
  };

  const s = { ...base, ...sizes[size], ...variants[variant], ...styleProp };

  return React.createElement('button', {
    style: s,
    onClick,
    disabled,
    ...rest,
  }, children);
}
