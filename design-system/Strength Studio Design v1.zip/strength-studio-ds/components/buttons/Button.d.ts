/**
 * Strength Studio button — pill-shaped, role-aware.
 * Use `primary` (Ember) for conversion, `secondary` (Ironstone) for nav/join,
 * `outline`/`ghost` for secondary/tertiary, `physio` (Basalt) for recovery contexts.
 *
 * @startingPoint section="Components" subtitle="Button variants" viewport="700x150"
 */
export interface ButtonProps {
  children: React.ReactNode;
  /** Visual variant */
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'physio' | 'physio-outline' | 'chip' | 'chip-active';
  /** Size preset */
  size?: 'sm' | 'md' | 'lg';
  onClick?: () => void;
  disabled?: boolean;
  /** Stretch to fill container width */
  fullWidth?: boolean;
  style?: React.CSSProperties;
}
export function Button(props: ButtonProps): JSX.Element;
