# Button

Pill-shaped CTA button for Strength Studio. Always uses `border-radius: 999px`.

## Usage
```jsx
<Button variant="primary">Book a movement assessment</Button>
<Button variant="secondary">Join Us</Button>
<Button variant="outline">Book Now</Button>
<Button variant="ghost">Learn more</Button>
<Button variant="physio">Book a recovery session</Button>
<Button variant="chip">Strength</Button>
<Button variant="chip-active">All</Button>
```

## Rules
- **Ember (primary)** — sales/conversion CTAs
- **Ironstone (secondary)** — primary nav actions like "Join Us"
- **Outline** — secondary actions next to a primary
- **Ghost** — tertiary / "learn more" style
- **Basalt (physio)** — physio/recovery contexts only; never swap with Ember
- **Chip / chip-active** — filter toggles
