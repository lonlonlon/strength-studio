/**
 * Stat counter row with vertical dividers — for hero overlays and proof sections.
 * Accent suffixes (+, ×, %, k) render in Ember by default.
 *
 * @startingPoint section="Components" subtitle="Stat counter row" viewport="700x100"
 */
export interface StatRowProps {
  stats: Array<{
    value: string;
    suffix?: string;
    label: string;
  }>;
  /** Color for the suffix character. Defaults to Ember. */
  accentColor?: string;
  style?: React.CSSProperties;
}
export function StatRow(props: StatRowProps): JSX.Element;
