export function StatRow({
  stats = [],
  accentColor = '#D15229',
  style: styleProp,
}) {
  const container = {
    display: 'grid',
    gridTemplateColumns: 'repeat(' + stats.length + ', 1fr)',
    gap: '24px',
    fontFamily: "'Manrope', system-ui, sans-serif",
    ...styleProp,
  };

  return React.createElement('div', { style: container },
    ...stats.map(function(stat, i) {
      var isLast = i === stats.length - 1;
      return React.createElement('div', {
        key: i,
        style: {
          borderRight: !isLast ? '1px solid #E6DED4' : 'none',
          paddingRight: !isLast ? '24px' : '0',
        },
      },
        React.createElement('div', {
          style: {
            fontSize: '42px',
            lineHeight: 1,
            letterSpacing: '-0.03em',
            fontWeight: 700,
            color: '#1F2225',
          },
        },
          stat.value,
          stat.suffix && React.createElement('span', {
            style: { color: accentColor },
          }, stat.suffix)
        ),
        React.createElement('div', {
          style: {
            fontSize: '12px',
            letterSpacing: '0.1em',
            textTransform: 'uppercase',
            color: '#847B71',
            marginTop: '10px',
            fontWeight: 600,
          },
        }, stat.label)
      );
    })
  );
}
