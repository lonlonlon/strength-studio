# StatRow

Stat counter row for Strength Studio proof sections and hero overlays.

## Usage
```jsx
<StatRow stats={[
  { value: '10k', suffix: '+', label: 'Hours of coaching' },
  { value: '8', suffix: '+', label: 'Years of experience' },
  { value: '1:1', label: 'Coach to member' },
  { value: '77', label: '@ East Coast' },
]} />
```

## Notes
- Numbers use Manrope 700 at 42px
- Suffix characters (+ × % k) render in Ember (accent color)
- Vertical dividers between items using Linen borders
- Use for hero proof bars and about sections
