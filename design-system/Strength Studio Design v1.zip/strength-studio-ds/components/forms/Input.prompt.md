# Input

Text input field for Strength Studio forms. Uses 10px radius, Manrope 15px. All states use Paper (#FFFFFF) fill — surface contrast comes from the border treatment.

## Usage
```jsx
<Input label="Full name" value="Eleanor Chen" state="active" helpText="Active — Ironstone border, Paper fill." />
<Input label="Primary goal" value="Return to running" state="rest" helpText="Rest — Paper fill, Linen border." />
<Input label="Email" placeholder="you@domain.com" state="empty" helpText="Empty — Paper fill, Linen border, placeholder Pebble." />
```

## States
- **rest** — Paper fill, Linen border. Filled-out, non-focused.
- **active** — Paper fill, 1.5px Ironstone border. Currently focused.
- **empty** — Paper fill, Linen border, Pebble placeholder. Empty/uninteracted.
