export function Select({
  label,
  value,
  options = [],
  open = false,
  onChange,
  helpText,
  style: styleProp,
}) {
  var labelStyle = {
    display: 'block',
    fontFamily: "'Manrope', system-ui, sans-serif",
    fontSize: '11px',
    letterSpacing: '0.1em',
    textTransform: 'uppercase',
    color: '#847B71',
    marginBottom: '8px',
    fontWeight: 600,
  };

  var triggerStyle = {
    width: '100%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '14px 16px',
    background: '#FFFFFF',
    border: open ? '1.5px solid #1F2225' : '1px solid #E6DED4',
    borderRadius: '10px',
    fontFamily: "'Manrope', system-ui, sans-serif",
    fontSize: '15px',
    color: value ? '#1F2225' : '#B8B1A4',
    cursor: 'pointer',
    textAlign: 'left',
  };

  var menuStyle = {
    position: 'absolute',
    top: 'calc(100% + 6px)',
    left: 0,
    right: 0,
    background: '#FFFFFF',
    border: '1px solid #E6DED4',
    borderRadius: '10px',
    boxShadow: '0 8px 24px rgba(31,34,37,0.08)',
    overflow: 'hidden',
    zIndex: 2,
  };

  var caret = React.createElement('svg', { width: 10, height: 6, viewBox: '0 0 10 6', fill: 'none' },
    React.createElement('path', { d: 'M1 1L5 5L9 1', stroke: open ? '#1F2225' : '#847B71', strokeWidth: 1.5, strokeLinecap: 'round', strokeLinejoin: 'round' })
  );

  var check = React.createElement('svg', { width: 14, height: 10, viewBox: '0 0 14 10', fill: 'none' },
    React.createElement('path', { d: 'M1 5L5 9L13 1', stroke: '#E05A2D', strokeWidth: 1.8, strokeLinecap: 'round', strokeLinejoin: 'round' })
  );

  return React.createElement('div', { style: styleProp },
    label && React.createElement('label', { style: labelStyle }, label),
    React.createElement('div', { style: { position: 'relative' } },
      React.createElement('button', { type: 'button', style: triggerStyle },
        React.createElement('span', null, value || 'Select…'),
        caret
      ),
      open && React.createElement('div', { style: menuStyle },
        options.map(function(opt, i) {
          var isSelected = opt === value;
          return React.createElement('div', {
            key: i,
            onClick: function() { if (onChange) onChange(opt); },
            style: {
              padding: '12px 16px',
              fontFamily: "'Manrope', system-ui, sans-serif",
              fontSize: '14px',
              color: '#1F2225',
              background: isSelected ? '#F4F0EB' : '#FFFFFF',
              borderTop: i > 0 ? '1px solid #E6DED4' : 'none',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              cursor: 'pointer',
            },
          }, React.createElement('span', null, opt), isSelected && check);
        })
      )
    ),
    helpText && React.createElement('div', {
      style: { fontFamily: "'Manrope', system-ui, sans-serif", fontSize: '12px', color: '#847B71', marginTop: '8px' },
    }, helpText)
  );
}
