/**
 * Strength Studio phone input — country selector + number side-by-side.
 * Defaults to Singapore (+65). Supports SG, MY, US, GB out of the box.
 *
 * @startingPoint section="Components" subtitle="Phone input with country selector" viewport="700x110"
 */
export interface PhoneInputProps {
  label?: string;
  value?: string;
  /** Two-letter country code. Defaults to 'SG'. */
  country?: 'SG' | 'MY' | 'US' | 'GB';
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onCountryChange?: () => void;
  helpText?: string;
  style?: React.CSSProperties;
}
export function PhoneInput(props: PhoneInputProps): JSX.Element;
