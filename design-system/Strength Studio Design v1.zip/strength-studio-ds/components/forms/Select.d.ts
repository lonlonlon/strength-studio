/**
 * Strength Studio dropdown / select component.
 * Closed state matches Input; open state shows a menu of options with the selected row highlighted in Canvas + Ember check.
 *
 * @startingPoint section="Components" subtitle="Dropdown / select" viewport="700x320"
 */
export interface SelectProps {
  label?: string;
  value?: string;
  options: string[];
  /** Show the open menu */
  open?: boolean;
  onChange?: (value: string) => void;
  helpText?: string;
  style?: React.CSSProperties;
}
export function Select(props: SelectProps): JSX.Element;
