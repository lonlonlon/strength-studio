# Select

Dropdown / select for Strength Studio forms. Same 10px radius family as Input; selected row uses Canvas (#F4F0EB) fill + Ember check mark.

## Usage
```jsx
<Select
  label="Preferred session time"
  value="Weekday mornings · 06–10 AM"
  options={[
    'Weekday mornings · 06–10 AM',
    'Weekday lunch · 12–02 PM',
    'Weekday evenings · 06–10 PM',
    'Weekend mornings',
    'Flexible — happy to discuss',
  ]}
  open={true}
  onChange={(v) => setTime(v)}
/>
```

## Behaviour
- **Closed:** matches Input rest state (Paper fill, Linen border) when value present; placeholder colour when empty.
- **Open:** trigger gets 1.5px Ironstone border (matches Input active); menu has Paper fill with soft Ironstone shadow.
- **Selected row:** Canvas (#F4F0EB) fill, Ember check icon. Hover state inherits.
