/**
 * Strength Studio multi-select chip group for forms.
 * Selected chips use Ironstone fill + check mark; unselected match the chip variant of Button.
 *
 * @startingPoint section="Components" subtitle="Multi-select chip group" viewport="700x140"
 */
export interface ChipSelectorProps {
  label?: string;
  /** Inline hint after the label (e.g. "select all that apply") */
  hint?: string;
  options: string[];
  selected?: string[];
  onChange?: (selected: string[]) => void;
  helpText?: string;
  style?: React.CSSProperties;
}
export function ChipSelector(props: ChipSelectorProps): JSX.Element;
