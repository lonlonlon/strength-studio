export function ChipSelector({
  label,
  hint,
  options = [],
  selected = [],
  onChange,
  helpText,
  style: styleProp,
}) {
  var labelStyle = {
    display: 'block',
    fontFamily: "'Manrope', system-ui, sans-serif",
    fontSize: '11px',
    letterSpacing: '0.1em',
    textTransform: 'uppercase',
    color: '#847B71',
    marginBottom: '8px',
    fontWeight: 600,
  };

  function toggle(opt) {
    if (!onChange) return;
    var next = selected.indexOf(opt) >= 0
      ? selected.filter(function(o) { return o !== opt; })
      : selected.concat([opt]);
    onChange(next);
  }

  return React.createElement('div', { style: styleProp },
    label && React.createElement('label', { style: labelStyle },
      label,
      hint && React.createElement('span', { style: { color: '#B8B1A4', fontWeight: 500 } }, ' · ' + hint)
    ),
    React.createElement('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '8px' } },
      options.map(function(opt, i) {
        var isSelected = selected.indexOf(opt) >= 0;
        var chipStyle = isSelected
          ? { background: '#1F2225', color: '#FFFFFF', border: '1px solid #1F2225' }
          : { background: 'transparent', color: '#1F2225', border: '1px solid #DDD9D2' };
        var base = {
          fontFamily: "'Manrope', system-ui, sans-serif",
          fontSize: '13px',
          fontWeight: 500,
          padding: '9px 16px',
          borderRadius: '999px',
          cursor: 'pointer',
          display: 'inline-flex',
          alignItems: 'center',
          gap: '8px',
          transition: 'background 0.15s, border-color 0.15s',
        };
        return React.createElement('button', {
          key: i,
          type: 'button',
          onClick: function() { toggle(opt); },
          style: Object.assign({}, base, chipStyle),
        },
          opt,
          isSelected && React.createElement('svg', { width: 10, height: 10, viewBox: '0 0 10 10', fill: 'none' },
            React.createElement('path', { d: 'M2 5L4.5 7.5L8 3', stroke: '#FFFFFF', strokeWidth: 1.6, strokeLinecap: 'round', strokeLinejoin: 'round' })
          )
        );
      })
    ),
    helpText && React.createElement('div', {
      style: { fontFamily: "'Manrope', system-ui, sans-serif", fontSize: '12px', color: '#847B71', marginTop: '12px' },
    }, helpText)
  );
}
