export function Input({
  label,
  value,
  placeholder,
  onChange,
  state = 'rest',
  helpText,
  style: styleProp,
  ...rest
}) {
  const labelStyle = {
    display: 'block',
    fontFamily: "'Manrope', system-ui, sans-serif",
    fontSize: '11px',
    letterSpacing: '0.1em',
    textTransform: 'uppercase',
    color: '#847B71',
    marginBottom: '8px',
    fontWeight: 600,
  };

  const states = {
    rest: {
      background: '#FFFFFF',
      border: '1px solid #E6DED4',
    },
    active: {
      background: '#FFFFFF',
      border: '1.5px solid #1F2225',
    },
    empty: {
      background: '#FFFFFF',
      border: '1px solid #E6DED4',
    },
  };

  const inputStyle = {
    width: '100%',
    padding: '14px 16px',
    borderRadius: '10px',
    fontFamily: "'Manrope', system-ui, sans-serif",
    fontSize: '15px',
    color: state === 'empty' ? '#B8B1A4' : '#1F2225',
    outline: 'none',
    transition: 'border-color 0.15s, background 0.15s',
    ...states[state],
  };

  const helpStyle = {
    fontFamily: "'Manrope', system-ui, sans-serif",
    fontSize: '12px',
    color: '#847B71',
    marginTop: '8px',
  };

  return React.createElement('div', { style: styleProp },
    label && React.createElement('label', { style: labelStyle }, label),
    React.createElement('input', {
      type: 'text',
      value,
      placeholder,
      onChange,
      style: inputStyle,
      ...rest,
    }),
    helpText && React.createElement('div', { style: helpStyle }, helpText)
  );
}
