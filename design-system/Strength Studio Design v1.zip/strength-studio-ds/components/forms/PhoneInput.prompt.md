# PhoneInput

Phone number input with country selector for Strength Studio forms. Country selector + number input sit side-by-side. Defaults to Singapore (+65).

## Usage
```jsx
<PhoneInput
  label="Phone"
  value="9123 4567"
  country="SG"
  onChange={(e) => setPhone(e.target.value)}
  onCountryChange={() => openCountryPicker()}
/>
```

## Notes
- Both fields share the rest-state Input treatment (Paper fill, Linen border, 10px radius).
- The country selector is a button that triggers a picker (you wire the picker yourself via `onCountryChange`).
- Defaults to `country="SG"`. Built-in support for SG, MY, US, GB. Add more by extending `COUNTRY_FLAGS` in the component.
- Number input uses tabular numerals for clean digit alignment.
