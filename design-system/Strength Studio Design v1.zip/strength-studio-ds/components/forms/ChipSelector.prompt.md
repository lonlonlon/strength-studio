# ChipSelector

Multi-select chip group for Strength Studio forms (areas of focus, available days, content tags). Selected chips use Ironstone fill + Paper check; unselected match the chip variant of Button.

## Usage
```jsx
<ChipSelector
  label="Areas of focus"
  hint="select all that apply"
  options={['Strength', 'Mobility', 'Physiotherapy', 'Longevity', 'Senior strength', 'Post-injury return']}
  selected={['Strength', 'Mobility']}
  onChange={(next) => setFocus(next)}
/>
```

## Rules
- For multi-select only. For single-select (filters), use Button `chip` / `chip-active` variants.
- Check icon appears only on selected chips.
- Same 9px×16px padding and 13px text as 6.1 chips — visually compatible.
