/**
 * Strength Studio text input with label and help text.
 * Three states: rest (Canvas fill), active (Paper fill + Ironstone border), empty (Canvas + Linen border).
 *
 * @startingPoint section="Components" subtitle="Form input" viewport="700x120"
 */
export interface InputProps {
  label?: string;
  value?: string;
  placeholder?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  /** Visual state */
  state?: 'rest' | 'active' | 'empty';
  /** Helper text shown below the input */
  helpText?: string;
  style?: React.CSSProperties;
}
export function Input(props: InputProps): JSX.Element;
