var COUNTRY_FLAGS = {
  SG: { code: '+65', name: 'Singapore', svg: '<rect width="22" height="7" fill="#EF3340"/><rect y="7" width="22" height="7" fill="#fff"/><circle cx="5" cy="3.5" r="1.8" fill="#fff"/><circle cx="5.7" cy="3.5" r="1.5" fill="#EF3340"/>' },
  MY: { code: '+60', name: 'Malaysia', svg: '<rect width="22" height="14" fill="#CC0001"/><rect width="22" height="1" y="2" fill="#fff"/><rect width="22" height="1" y="4" fill="#fff"/><rect width="22" height="1" y="6" fill="#fff"/><rect width="22" height="1" y="8" fill="#fff"/><rect width="22" height="1" y="10" fill="#fff"/><rect width="22" height="1" y="12" fill="#fff"/><rect width="10" height="7" fill="#000066"/>' },
  US: { code: '+1', name: 'United States', svg: '<rect width="22" height="14" fill="#fff"/><rect width="22" height="1" y="0" fill="#B22234"/><rect width="22" height="1" y="2" fill="#B22234"/><rect width="22" height="1" y="4" fill="#B22234"/><rect width="22" height="1" y="6" fill="#B22234"/><rect width="22" height="1" y="8" fill="#B22234"/><rect width="22" height="1" y="10" fill="#B22234"/><rect width="22" height="1" y="12" fill="#B22234"/><rect width="9" height="7" fill="#3C3B6E"/>' },
  GB: { code: '+44', name: 'United Kingdom', svg: '<rect width="22" height="14" fill="#012169"/><path d="M0 0L22 14M22 0L0 14" stroke="#fff" stroke-width="2"/><path d="M11 0V14M0 7H22" stroke="#fff" stroke-width="3"/><path d="M11 0V14M0 7H22" stroke="#C8102E" stroke-width="1.5"/>' },
};

export function PhoneInput({
  label = 'Phone',
  value = '',
  country = 'SG',
  onChange,
  onCountryChange,
  helpText,
  style: styleProp,
}) {
  var c = COUNTRY_FLAGS[country] || COUNTRY_FLAGS.SG;

  var labelStyle = {
    display: 'block',
    fontFamily: "'Manrope', system-ui, sans-serif",
    fontSize: '11px',
    letterSpacing: '0.1em',
    textTransform: 'uppercase',
    color: '#847B71',
    marginBottom: '8px',
    fontWeight: 600,
  };

  var flag = React.createElement('svg', {
    width: 22,
    height: 14,
    viewBox: '0 0 22 14',
    style: { borderRadius: '2px', flexShrink: 0 },
    'aria-label': c.name,
    dangerouslySetInnerHTML: { __html: c.svg },
  });

  return React.createElement('div', { style: styleProp },
    React.createElement('label', { style: labelStyle }, label),
    React.createElement('div', { style: { display: 'flex', gap: '8px' } },
      React.createElement('button', {
        type: 'button',
        onClick: onCountryChange,
        style: {
          display: 'flex', alignItems: 'center', gap: '10px',
          padding: '14px 14px 14px 12px',
          background: '#FFFFFF', border: '1px solid #E6DED4', borderRadius: '10px',
          fontFamily: "'Manrope', system-ui, sans-serif", fontSize: '15px', color: '#1F2225',
          cursor: 'pointer', flexShrink: 0,
        },
      },
        flag,
        React.createElement('span', { style: { fontWeight: 500 } }, c.code),
        React.createElement('svg', { width: 10, height: 6, viewBox: '0 0 10 6', fill: 'none' },
          React.createElement('path', { d: 'M1 1L5 5L9 1', stroke: '#847B71', strokeWidth: 1.5, strokeLinecap: 'round', strokeLinejoin: 'round' })
        )
      ),
      React.createElement('input', {
        type: 'tel',
        value: value,
        onChange: onChange,
        placeholder: '0000 0000',
        style: {
          flex: 1, padding: '14px 16px',
          background: '#FFFFFF', border: '1px solid #E6DED4', borderRadius: '10px',
          fontFamily: "'Manrope', system-ui, sans-serif", fontSize: '15px', color: '#1F2225',
          outline: 'none', fontVariantNumeric: 'tabular-nums',
        },
      })
    ),
    helpText && React.createElement('div', {
      style: { fontFamily: "'Manrope', system-ui, sans-serif", fontSize: '12px', color: '#847B71', marginTop: '8px' },
    }, helpText)
  );
}
