export function SectionHeader({
  overline,
  headline,
  overlineColor = '#E05A2D',
  align = 'left',
  style: styleProp,
}) {
  var container = {
    fontFamily: "'Manrope', system-ui, sans-serif",
    textAlign: align,
    ...styleProp,
  };

  var overlineStyle = {
    fontSize: '11px',
    fontWeight: 600,
    letterSpacing: '0.14em',
    textTransform: 'uppercase',
    color: overlineColor,
    marginBottom: '12px',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    justifyContent: align === 'center' ? 'center' : 'flex-start',
  };

  var dashStyle = {
    display: 'inline-block',
    width: '16px',
    height: '1.5px',
    background: overlineColor,
    flexShrink: 0,
  };

  var headlineStyle = {
    fontSize: '28px',
    fontWeight: 700,
    color: '#1F2225',
    lineHeight: 1.25,
    maxWidth: '560px',
    margin: align === 'center' ? '0 auto' : undefined,
  };

  return React.createElement('div', { style: container },
    overline && React.createElement('div', { style: overlineStyle },
      React.createElement('span', { style: dashStyle }),
      overline
    ),
    React.createElement('h2', { style: headlineStyle }, headline)
  );
}
