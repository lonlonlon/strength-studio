/**
 * Section header with em-dash overline label and h2 headline.
 * Use to introduce content sections on marketing pages.
 *
 * @startingPoint section="Components" subtitle="Section heading" viewport="700x100"
 */
export interface SectionHeaderProps {
  overline?: string;
  headline: string;
  /** Overline colour — defaults to Ember. Use Basalt for physio sections. */
  overlineColor?: string;
  align?: 'left' | 'center';
  style?: React.CSSProperties;
}
export function SectionHeader(props: SectionHeaderProps): JSX.Element;
