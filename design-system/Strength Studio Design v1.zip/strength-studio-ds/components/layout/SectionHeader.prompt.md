# SectionHeader

Section heading pattern for Strength Studio marketing pages. Em-dash overline label above an h2 headline.

## Usage
```jsx
<SectionHeader
  overline="About Strength Studio"
  headline="Built around your body. Engineered for your movement."
/>
```

## Variants
- Ember overline (default) — training and general sections
- Basalt overline — physio and recovery sections: `overlineColor="#3D6A60"`
- Centered — `align="center"` for hero sub-sections

## Rules
- Overline: 11px, uppercase, letter-spaced, with leading em-dash
- Headline: Manrope 700, 28px, Ironstone
- Max headline width ~560px for readability
