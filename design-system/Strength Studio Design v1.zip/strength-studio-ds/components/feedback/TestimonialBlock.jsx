export function TestimonialBlock({
  quote,
  name,
  detail,
  avatarSrc,
  style: styleProp,
}) {
  var container = {
    background: '#FFFFFF',
    borderRadius: '16px',
    padding: '40px 36px',
    fontFamily: "'Manrope', system-ui, sans-serif",
    border: '1px solid #DDD9D2',
    ...styleProp,
  };

  var quoteStyle = {
    fontFamily: "'Instrument Serif', serif",
    fontStyle: 'italic',
    fontSize: '24px',
    lineHeight: 1.5,
    color: '#1F2225',
    marginBottom: '28px',
  };

  var attrRow = {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
  };

  var avatarStyle = {
    width: '40px',
    height: '40px',
    borderRadius: '50%',
    background: '#E6DED4',
    flexShrink: 0,
    overflow: 'hidden',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  };

  var avatarImg = {
    width: '100%',
    height: '100%',
    objectFit: 'cover',
  };

  var avatarInitial = {
    fontSize: '14px',
    fontWeight: 600,
    color: '#847B71',
  };

  var nameStyle = {
    fontSize: '14px',
    fontWeight: 600,
    color: '#1F2225',
  };

  var detailStyle = {
    fontSize: '13px',
    color: '#847B71',
  };

  return React.createElement('div', { style: container },
    React.createElement('div', { style: quoteStyle },
      '"' + quote + '"'
    ),
    React.createElement('div', { style: attrRow },
      React.createElement('div', { style: avatarStyle },
        avatarSrc
          ? React.createElement('img', { src: avatarSrc, alt: name, style: avatarImg })
          : React.createElement('span', { style: avatarInitial }, name ? name.charAt(0) : '?')
      ),
      React.createElement('div', null,
        React.createElement('div', { style: nameStyle }, name),
        detail && React.createElement('div', { style: detailStyle }, detail)
      )
    )
  );
}
