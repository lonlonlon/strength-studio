# TestimonialBlock

Pull-quote testimonial card for Strength Studio member social proof.

## Usage
```jsx
<TestimonialBlock
  quote="After six months, I'm stronger at 52 than I was at 30. The programming is the difference — nothing's there by accident."
  name="James K."
  detail="Founding member · 52 · Strength programming"
/>
```

## Anatomy
1. Quote — Instrument Serif 400 italic, 24px, wrapped in quotation marks
2. Attribution row — avatar circle, name (Manrope 600), detail line (Flint)

## Rules
- Instrument Serif italic for the quote text — this is its primary use
- Once per screen maximum
- Paper background, bordered, 16px radius
- Avatar falls back to initial letter on Linen circle
