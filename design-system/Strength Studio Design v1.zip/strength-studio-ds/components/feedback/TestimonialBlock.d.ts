/**
 * Pull-quote testimonial block with Instrument Serif italic text.
 * Use once per screen for member social proof.
 *
 * @startingPoint section="Components" subtitle="Member testimonial" viewport="500x260"
 */
export interface TestimonialBlockProps {
  quote: string;
  name: string;
  detail?: string;
  avatarSrc?: string;
  style?: React.CSSProperties;
}
export function TestimonialBlock(props: TestimonialBlockProps): JSX.Element;
