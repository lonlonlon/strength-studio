/**
 * Strength Studio empty-state placeholder.
 * Use for "no sessions this week", "no members assigned", "no notes yet" — anywhere the dashboard or list would otherwise be blank.
 *
 * @startingPoint section="Components" subtitle="Empty state placeholder" viewport="700x340"
 */
export interface EmptyStateAction {
  label: string;
  onClick?: () => void;
}
export interface EmptyStateProps {
  overline?: string;
  title?: string;
  description?: string;
  primaryAction?: EmptyStateAction;
  secondaryAction?: EmptyStateAction;
  /** Ember (training) or Basalt (physio) accent. */
  variant?: 'training' | 'physio';
  /** Custom illustration node. Defaults to a circular icon. */
  illustration?: React.ReactNode;
  style?: React.CSSProperties;
}
export function EmptyState(props: EmptyStateProps): JSX.Element;
