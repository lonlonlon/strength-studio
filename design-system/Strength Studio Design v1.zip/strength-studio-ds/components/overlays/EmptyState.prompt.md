# EmptyState

Centered placeholder for empty lists, zero-result searches, and pre-data dashboard states. Paper card on Canvas, accent ring around an icon slot.

## Usage
```jsx
<EmptyState
  overline="This week"
  title="No sessions scheduled"
  description="Eleanor doesn't have anything booked between Mon 24 and Sun 30 Jun."
  primaryAction={{ label: 'Schedule a session', onClick: openScheduler }}
  secondaryAction={{ label: 'View past sessions', onClick: showHistory }}
  variant="training"
/>
```

## Rules
- **variant="training"** for strength/training contexts (Ember accent).
- **variant="physio"** for recovery/physio contexts (Basalt accent).
- Drop in a real `illustration` once we have brand iconography; the default is a placeholder.
- Stay specific in the description — "Eleanor doesn't have anything booked between Mon 24 and Sun 30 Jun" is better than "Nothing here yet."
