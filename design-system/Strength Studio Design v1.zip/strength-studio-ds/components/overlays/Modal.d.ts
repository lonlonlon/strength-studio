/**
 * Strength Studio modal dialog.
 * Used for booking confirmations, assessment summaries, session-note entry. 16px radius, Paper surface, Ironstone backdrop scrim.
 *
 * @startingPoint section="Components" subtitle="Modal dialog" viewport="700x420"
 */
export interface ModalAction {
  label: string;
  onClick?: () => void;
}
export interface ModalProps {
  open?: boolean;
  title?: string;
  description?: string;
  children?: React.ReactNode;
  onClose?: () => void;
  primaryAction?: ModalAction;
  secondaryAction?: ModalAction;
  /** Switches the overline + primary action accent between Ember (training) and Basalt (physio). */
  variant?: 'training' | 'physio';
  width?: number;
}
export function Modal(props: ModalProps): JSX.Element | null;
