# Modal

Modal dialog for booking confirmation, assessment summaries, and session-note entry. Paper card centered over an Ironstone-tinted backdrop.

## Usage
```jsx
<Modal
  open={open}
  title="Confirm your booking"
  description="Eleanor, you're booking a movement assessment with Bernard Sim on Tuesday, 24 June at 09:00."
  primaryAction={{ label: 'Confirm booking', onClick: handleConfirm }}
  secondaryAction={{ label: 'Back', onClick: handleClose }}
  onClose={handleClose}
  variant="training"
/>
```

## Rules
- **variant="training"** — Ember overline + Ember primary action.
- **variant="physio"** — Basalt overline + Basalt primary action.
- Header overline tells the user which side of the studio the action belongs to.
- Backdrop click + ESC + close button all dismiss via `onClose`.
- 16px radius, no shadow on the dialog itself (uses a soft elevation shadow from the backdrop only — see component for the tuned value).
