export function Toast({
  variant = 'success',
  title,
  description,
  action,
  onClose,
  style: styleProp,
}) {
  var variants = {
    success: { dot: '#3D6A60', overline: 'Confirmed' },
    info: { dot: '#1F2225', overline: 'Heads up' },
    action: { dot: '#E05A2D', overline: 'Action needed' },
  };
  var v = variants[variant] || variants.success;

  var container = {
    display: 'inline-flex', alignItems: 'flex-start', gap: '16px',
    background: '#1F2225', color: '#F4F0EB',
    fontFamily: "'Manrope', system-ui, sans-serif",
    padding: '16px 20px',
    borderRadius: '12px',
    maxWidth: '420px',
    boxShadow: '0 12px 32px rgba(31,34,37,0.24)',
    ...styleProp,
  };

  return React.createElement('div', { style: container },
    React.createElement('span', {
      style: { display: 'block', width: '8px', height: '8px', borderRadius: '50%', background: v.dot, marginTop: '8px', flexShrink: 0 },
    }),
    React.createElement('div', { style: { flex: 1, minWidth: 0 } },
      React.createElement('div', {
        style: { fontSize: '10px', letterSpacing: '0.14em', textTransform: 'uppercase', color: v.dot, fontWeight: 600, marginBottom: '4px' },
      }, v.overline),
      title && React.createElement('div', {
        style: { fontSize: '14px', fontWeight: 600, color: '#FFFFFF', marginBottom: description ? '2px' : 0 },
      }, title),
      description && React.createElement('div', {
        style: { fontSize: '13px', lineHeight: 1.5, color: '#B8B1A4' },
      }, description),
      action && React.createElement('button', {
        type: 'button', onClick: action.onClick,
        style: {
          marginTop: '10px',
          background: 'transparent', border: 'none', padding: 0, cursor: 'pointer',
          fontFamily: 'inherit', fontSize: '12px', fontWeight: 600,
          color: '#FFFFFF', textDecoration: 'underline', textUnderlineOffset: '3px',
        },
      }, action.label)
    ),
    onClose && React.createElement('button', {
      type: 'button', onClick: onClose,
      style: { background: 'transparent', border: 'none', cursor: 'pointer', color: '#847B71', padding: '4px', marginLeft: '4px', flexShrink: 0 },
      'aria-label': 'Dismiss',
    },
      React.createElement('svg', { width: 12, height: 12, viewBox: '0 0 12 12', fill: 'none' },
        React.createElement('path', { d: 'M2 2L10 10M10 2L2 10', stroke: 'currentColor', strokeWidth: 1.5, strokeLinecap: 'round' })
      )
    )
  );
}
