# Toast

Inline notification for confirmation, info, or action-needed states. Ironstone surface with a coloured status dot — never floating in the page background.

## Usage
```jsx
<Toast
  variant="success"
  title="Booking confirmed"
  description="You'll get a calendar invite shortly."
  onClose={dismiss}
/>

<Toast
  variant="action"
  title="Assessment due"
  description="Eleanor's 8-week re-assessment is now overdue."
  action={{ label: 'Schedule now', onClick: schedule }}
  onClose={dismiss}
/>
```

## Variants
- **success** — Basalt dot, "Confirmed" overline. Booking, payment, recovery milestone.
- **info** — Ironstone dot, "Heads up" overline. Quiet system messages.
- **action** — Ember dot, "Action needed" overline. Coach must act (overdue assessment, missing notes).

## Behaviour
- Stays in the Ironstone register so it doesn't compete with Canvas surfaces.
- Auto-dismiss after ~4s for `success` / `info`; `action` persists until acknowledged.
