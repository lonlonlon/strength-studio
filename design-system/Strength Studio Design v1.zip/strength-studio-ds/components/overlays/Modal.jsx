export function Modal({
  open = true,
  title,
  description,
  children,
  onClose,
  primaryAction,
  secondaryAction,
  variant = 'training',
  width = 480,
}) {
  if (!open) return null;

  var accent = variant === 'physio' ? '#3D6A60' : '#E05A2D';

  var backdrop = {
    position: 'fixed', inset: 0,
    background: 'rgba(31, 34, 37, 0.55)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    padding: '24px', zIndex: 100,
  };

  var dialog = {
    background: '#FFFFFF',
    borderRadius: '16px',
    width: '100%', maxWidth: width + 'px',
    fontFamily: "'Manrope', system-ui, sans-serif",
    color: '#1F2225',
    boxShadow: '0 24px 60px rgba(31,34,37,0.18)',
    overflow: 'hidden',
  };

  return React.createElement('div', { style: backdrop, onClick: onClose },
    React.createElement('div', { style: dialog, onClick: function(e) { e.stopPropagation(); } },
      // Header
      React.createElement('div', { style: { padding: '28px 32px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '24px' } },
        React.createElement('div', null,
          React.createElement('div', {
            style: { fontSize: '11px', letterSpacing: '0.14em', textTransform: 'uppercase', color: accent, fontWeight: 600, marginBottom: '10px' },
          }, variant === 'physio' ? 'Recovery' : 'Training'),
          title && React.createElement('div', {
            style: { fontSize: '22px', lineHeight: 1.2, letterSpacing: '-0.015em', fontWeight: 700 },
          }, title)
        ),
        onClose && React.createElement('button', {
          type: 'button', onClick: onClose,
          style: {
            background: 'transparent', border: 'none', cursor: 'pointer',
            color: '#847B71', padding: '4px', display: 'flex', alignItems: 'center', justifyContent: 'center',
          },
          'aria-label': 'Close',
        },
          React.createElement('svg', { width: 16, height: 16, viewBox: '0 0 16 16', fill: 'none' },
            React.createElement('path', { d: 'M3 3L13 13M13 3L3 13', stroke: 'currentColor', strokeWidth: 1.5, strokeLinecap: 'round' })
          )
        )
      ),
      // Body
      React.createElement('div', { style: { padding: '20px 32px 28px' } },
        description && React.createElement('div', {
          style: { fontSize: '14px', lineHeight: 1.6, color: '#2E3330' },
        }, description),
        children && React.createElement('div', { style: { marginTop: description ? '16px' : 0 } }, children)
      ),
      // Footer
      (primaryAction || secondaryAction) && React.createElement('div', {
        style: { padding: '20px 32px', borderTop: '1px solid #E6DED4', display: 'flex', gap: '12px', justifyContent: 'flex-end' },
      },
        secondaryAction && React.createElement('button', {
          type: 'button', onClick: secondaryAction.onClick,
          style: {
            fontFamily: "'Manrope', system-ui, sans-serif", fontSize: '14px', fontWeight: 600,
            padding: '12px 22px', borderRadius: '999px',
            background: 'transparent', color: '#1F2225', border: '1px solid #DDD9D2', cursor: 'pointer',
          },
        }, secondaryAction.label),
        primaryAction && React.createElement('button', {
          type: 'button', onClick: primaryAction.onClick,
          style: {
            fontFamily: "'Manrope', system-ui, sans-serif", fontSize: '14px', fontWeight: 600,
            padding: '12px 22px', borderRadius: '999px',
            background: accent, color: '#FFFFFF', border: 'none', cursor: 'pointer',
          },
        }, primaryAction.label)
      )
    )
  );
}
