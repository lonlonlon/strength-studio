export function EmptyState({
  overline,
  title,
  description,
  primaryAction,
  secondaryAction,
  variant = 'training',
  illustration,
  style: styleProp,
}) {
  var accent = variant === 'physio' ? '#3D6A60' : '#E05A2D';

  var container = {
    background: '#FFFFFF',
    borderRadius: '16px',
    padding: '56px 40px',
    fontFamily: "'Manrope', system-ui, sans-serif",
    color: '#1F2225',
    textAlign: 'center',
    boxShadow: '0 1px 0 #DDD9D2',
    display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '20px',
    ...styleProp,
  };

  return React.createElement('div', { style: container },
    illustration || React.createElement('div', {
      style: {
        width: '64px', height: '64px', borderRadius: '50%',
        background: '#F4F0EB', display: 'flex', alignItems: 'center', justifyContent: 'center',
      },
    },
      React.createElement('svg', { width: 24, height: 24, viewBox: '0 0 24 24', fill: 'none' },
        React.createElement('circle', { cx: 12, cy: 12, r: 10, stroke: accent, strokeWidth: 1.5 }),
        React.createElement('path', { d: 'M8 12H16M12 8V16', stroke: accent, strokeWidth: 1.5, strokeLinecap: 'round' })
      )
    ),
    React.createElement('div', null,
      overline && React.createElement('div', {
        style: { fontSize: '11px', letterSpacing: '0.14em', textTransform: 'uppercase', color: accent, fontWeight: 600, marginBottom: '12px' },
      }, overline),
      title && React.createElement('div', {
        style: { fontSize: '24px', lineHeight: 1.2, letterSpacing: '-0.02em', fontWeight: 700, marginBottom: '12px' },
      }, title),
      description && React.createElement('div', {
        style: { fontSize: '14px', lineHeight: 1.6, color: '#847B71', maxWidth: '420px', margin: '0 auto' },
      }, description)
    ),
    (primaryAction || secondaryAction) && React.createElement('div', {
      style: { display: 'flex', gap: '10px', marginTop: '4px' },
    },
      primaryAction && React.createElement('button', {
        type: 'button', onClick: primaryAction.onClick,
        style: {
          fontFamily: "'Manrope', system-ui, sans-serif", fontSize: '14px', fontWeight: 600,
          padding: '13px 22px', borderRadius: '999px',
          background: accent, color: '#FFFFFF', border: 'none', cursor: 'pointer',
        },
      }, primaryAction.label),
      secondaryAction && React.createElement('button', {
        type: 'button', onClick: secondaryAction.onClick,
        style: {
          fontFamily: "'Manrope', system-ui, sans-serif", fontSize: '14px', fontWeight: 600,
          padding: '13px 22px', borderRadius: '999px',
          background: 'transparent', color: '#1F2225', border: '1.5px solid #1F2225', cursor: 'pointer',
        },
      }, secondaryAction.label)
    )
  );
}
