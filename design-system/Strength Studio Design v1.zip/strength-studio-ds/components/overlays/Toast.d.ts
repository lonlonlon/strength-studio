/**
 * Strength Studio toast — inline confirmation, info, or action-needed notification.
 * Always sits on Ironstone with a coloured status dot. Three variants.
 *
 * @startingPoint section="Components" subtitle="Toast notification" viewport="700x140"
 */
export interface ToastAction {
  label: string;
  onClick?: () => void;
}
export interface ToastProps {
  /** `success` = Basalt dot, `info` = Ironstone dot, `action` = Ember dot. */
  variant?: 'success' | 'info' | 'action';
  title?: string;
  description?: string;
  action?: ToastAction;
  onClose?: () => void;
  style?: React.CSSProperties;
}
export function Toast(props: ToastProps): JSX.Element;
