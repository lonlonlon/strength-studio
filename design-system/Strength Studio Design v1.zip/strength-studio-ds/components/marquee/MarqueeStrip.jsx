export function MarqueeStrip({
  items = [],
  separator = '•',
  speed = 30,
  style: styleProp,
}) {
  var container = {
    background: '#E05A2D',
    overflow: 'hidden',
    whiteSpace: 'nowrap',
    fontFamily: "'Instrument Serif', serif",
    fontStyle: 'italic',
    fontSize: '22px',
    color: '#FFFFFF',
    padding: '14px 0',
    ...styleProp,
  };

  var text = items.join('  ' + separator + '  ');
  var repeated = text + '  ' + separator + '  ' + text + '  ' + separator + '  ' + text + '  ' + separator + '  ';

  var trackStyle = {
    display: 'inline-block',
    animation: 'marquee-scroll ' + speed + 's linear infinite',
    paddingRight: '24px',
  };

  var keyframes = '@keyframes marquee-scroll { 0% { transform: translateX(0); } 100% { transform: translateX(-33.333%); } }';

  return React.createElement('div', { style: container },
    React.createElement('style', null, keyframes),
    React.createElement('div', { style: trackStyle }, repeated)
  );
}
