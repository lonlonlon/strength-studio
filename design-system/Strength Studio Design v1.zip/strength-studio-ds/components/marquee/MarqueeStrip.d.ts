/**
 * Full-bleed Ember marquee strip with Instrument Serif italic text.
 * Use for service keywords between hero and content sections.
 *
 * @startingPoint section="Components" subtitle="Scrolling keyword strip" viewport="700x56"
 */
export interface MarqueeStripProps {
  items?: string[];
  separator?: string;
  /** Seconds for one full loop. Lower = faster. Default 30. */
  speed?: number;
  style?: React.CSSProperties;
}
export function MarqueeStrip(props: MarqueeStripProps): JSX.Element;
