# MarqueeStrip

Full-bleed Ember scrolling strip for Strength Studio. Instrument Serif italic, white text, continuous loop.

## Usage
```jsx
<MarqueeStrip
  items={['Personalised', 'Strength Training', 'Mobility & Stability', 'Physiotherapy', 'Longevity']}
/>
```

## Rules
- Always Ember (#E05A2D) background, full width
- Instrument Serif 400 italic, white text
- Bullet separator between items
- Use between hero and content sections, or as a visual break
- One per page maximum
