# Strength Studio — Design System

> **Where strength meets science.** A specialised fitness studio at 77 @ East Coast, Singapore — combining evidence-based strength programming with physiotherapy expertise for active adults.

**Parent company:** JSF Transformative Pte Ltd  
**Domain:** strength.sg  
**Instagram:** @strength.sg

---

## Sources

- Brand Guidelines v1.0 (May 2026) — colour palette, typography, gradients, logo direction
- Brand Strategy & Launch Marketing Plan — positioning, services, pricing, messaging
- Lead Trainer Discovery Questionnaire — Bernard Sim's methodology, client segments, session format
- Homepage wireframe mockup — IA, layout, component patterns
- Foundations document v0.2 — locked direction (this system)

---

## Brand Essence

**Positioning:** Premium strength training and physiotherapy studio — not a traditional gym. Appointment-based, 1:1 and semi-private. The combination of strength and physio occupies the middle ground where performance meets rehabilitation.

**Tagline:** "Where strength meets science"

**Pillars:**
1. **Science-backed** — evidence-based programming, not fitness fads
2. **Personalised** — no cookie-cutter programs, every plan built around the assessment
3. **Longevity-focused** — training for decades, not seasons
4. **Expert-led** — dual-credentialed professionals (strength + physio)

**Key services:**
- Movement Assessment (60 min entry point)
- Strength Programming: Solo Track (1:1) · Duo Track (2 pax) · Crew Track (3–4 pax)
- Packages: Foundation (8 sessions) · Momentum (16) · Mastery (24)
- Recovery Sessions (physio-led)
- Programming Only (remote)

---

## Content Fundamentals

### Voice Principles
1. **Specific over vague.** "Foundation — 8 sessions, 12 weeks, two re-assessments." Not "transform your body."
2. **Calm, not motivational.** No exclamation marks. No "crush," "smash," "destroy." Adults talking to adults.
3. **Evidence as quiet authority.** When we cite physiology or research, do it once and move on. Never lecture.
4. **Respect the reader's time.** Short sentences. Short paragraphs. If a page needs a tour to navigate, it's wrong.

### Vocabulary
| We say | We don't |
|---|---|
| Programming | Workouts |
| Sessions | Classes |
| Movement assessment | Bootcamp |
| Recovery | Cooldown |
| Coach | Trainer |
| Members | Clients |
| Studio | Gym |
| Resilience | Beast mode |

### Tone
- Expert but accessible
- Confident without arrogance
- Scientific yet human
- Premium without pretension
- No emoji in brand copy
- Sentence case for headlines (not Title Case, not ALL CAPS)
- The logotype "Strength Studio" is always sentence case

---

## Visual Foundations

### Colour Palette

**Core anchors (4):**
| Name | Hex | Role |
|---|---|---|
| Ironstone | `#1F2225` | Primary dark — headlines, nav, hero backgrounds, footer |
| Canvas | `#F4F0EB` | Primary light — default page background |
| Ember | `#D15229` | Action accent — CTAs, training labels, active states ("the do colour") |
| Basalt | `#3D6A60` | Heal accent — physio sections, recovery content ("the heal colour") |

**Supporting:**
| Name | Hex | Role |
|---|---|---|
| Linen | `#E6DED4` | Alternating section bg, card surfaces, input rest |
| Flint | `#847B71` | Body copy, captions, metadata |
| Charcoal | `#2E3330` | Subheadings, label emphasis, strong body |
| Paper | `#FFFFFF` | Card surfaces floating on Canvas |
| Border | `#DDD9D2` | Default hairlines and dividers |

**Usage proportions:**
- Canvas + Paper: ~60% (page surface)
- Ironstone + Charcoal: ~25% (type, hero, dark sections)
- Flint: ~10% (body text)
- Ember + Basalt: ~5% (reserved accents — never a wash)

**Rule:** Ember is for training/action. Basalt is for physio/recovery. Never swap them.

### Typography

Three-font system. All open-source via Google Fonts.

| Face | Role | Weights |
|---|---|---|
| **Special Gothic Expanded One** | Logotype + monogram ONLY. Never headlines or body. | 400 |
| **Manrope** | UI & body — headlines, body, nav, CTAs, labels, metadata. Everywhere. | 300, 400, 500, 600, 700 |
| **Instrument Serif** | Display & campaign — hero headlines, taglines, pull quotes, testimonials. Once per screen max. | 400, 400 italic |

**Type scale:**
| Element | Size | Weight | Font |
|---|---|---|---|
| Display | 88px | 400 | Instrument Serif |
| H1 | 48px | 700 | Manrope |
| H2 | 28px | 700 | Manrope |
| H3 | 20px | 600 | Manrope |
| Body | 16px | 400 | Manrope |
| Caption | 13px | 400 | Manrope |
| Label | 11px UC | 600 | Manrope |
| Pull quote | 24px | 400i | Instrument Serif |

### Shapes & Radius
| Token | Value | Use |
|---|---|---|
| `--radius-xs` | 4px | Inline elements, small tags |
| `--radius-sm` | 6px | Badge backgrounds |
| `--radius-md` | 10px | Form inputs |
| `--radius-lg` | 14px | Supporting cards |
| `--radius-xl` | 16px | Primary cards, pillar cards |
| `--radius-pill` | 999px | Buttons, chips, CTAs |

### Backgrounds & Surfaces
- **Canvas** (`#F4F0EB`) is the default page background — warm, never clinical
- **Paper** (`#FFFFFF`) for cards floating on Canvas — surface contrast IS the elevation
- **Linen** (`#E6DED4`) for alternating sections and pillar cards
- **Ironstone** (`#1F2225`) for hero bands, footer, dark sections
- No gradients on core website backgrounds (reserved for social/campaigns per brand guidelines)
- No shadows — elevation comes from surface contrast

### Hover & Press States
- Buttons: darken fill by 8% on hover, 12% on press
- Outline buttons: fill with Canvas on hover
- Ghost buttons: fill with Linen on hover
- Links: underline on hover
- Cards: no hover effect on static cards; interactive cards get subtle border darkening

### Logo
- Logotype in **sentence case**: "Strength Studio" (never all caps)
- Special Gothic Expanded One is logotype-only
- Clear space = height of the "S" on all sides
- Minimum: 24px digital / 20mm print
- Three variants: colour (Ironstone + Ember), reversed (white on dark), mono (all Ironstone)
- The mark stays contained — no cropping, oversizing, or pattern-repeating

### Iconography
- No icon system defined yet — to be established
- No emoji in brand materials
- Avoid decorative SVG illustrations; use photography placeholders instead
- When icons are needed, use a simple line-weight system consistent with Manrope's stroke weight

---

## Components

### Navigation & Layout
| Component | Location | Description |
|---|---|---|
| Navbar | `components/navigation/` | Site nav — light (Paper/scroll) and dark (reversed over hero) variants |
| Hero | `components/hero/` | Homepage hero — Ironstone surface, display headline, dual CTAs, image placeholder |
| SectionHeader | `components/layout/` | Em-dash overline + h2 headline pattern for page sections |
| MarqueeStrip | `components/marquee/` | Full-bleed Ember scrolling strip, Instrument Serif italic |
| Footer | `components/footer/` | Ember site footer with oversized wordmark and rounded top corners |

### Actions & Forms
| Component | Location | Description |
|---|---|---|
| Button | `components/buttons/` | Primary (Ember), secondary (Ironstone), outline, ghost, physio (Basalt), chips |
| Input | `components/forms/` | Text input with label — rest, active, empty states (all Paper fill, Linen/Ironstone border) |
| Select | `components/forms/` | Dropdown — selected row uses Canvas + Ember check |
| ChipSelector | `components/forms/` | Multi-select chip group — Ironstone fill + check when selected |
| PhoneInput | `components/forms/` | Phone number with country selector (SG default) |

### Content
| Component | Location | Description |
|---|---|---|
| Badge | `components/badges/` | Tag labels — training, physio, foundation, member-only |
| StatusBadge | `components/badges/` | Pill-shaped progress indicators — on-track, assessment-due, completed, paused |
| StatRow | `components/stats/` | Stat counter row with dividers |
| ServiceCard | `components/cards/` | Clinical spec-sheet service card with metadata rows |
| DarkCard | `components/cards/` | Charcoal surface feature card — CTA and proof variants |
| PillarCard | `components/cards/` | Linen surface card with numbered index for brand pillars |
| PillarRow | `components/cards/` | Horizontal pillar row — index + title left, description right |
| PricingTier | `components/cards/` | Package comparison card — featured tier gets a 2px Ember border on Paper |
| TrainerCard | `components/cards/` | Portrait card for trainer profiles with role, stats, tags |
| TestimonialBlock | `components/feedback/` | Pull-quote block — Instrument Serif italic with avatar attribution |

### Dashboard primitives
| Component | Location | Description |
|---|---|---|
| DataTable | `components/tables/` | Coach dashboard data table — Canvas header, Paper rows, status badges |
| Modal | `components/overlays/` | Centered dialog for confirmations, assessments, notes — training / physio variants |
| Toast | `components/overlays/` | Inline notification on Ironstone — success / info / action variants |
| EmptyState | `components/overlays/` | Centered placeholder for blank lists and zero-result states |

---

## Assets

| File | Description |
|---|---|
| `assets/logo-color.svg` | Primary logo — Ironstone + Ember on light backgrounds |
| `assets/logo-black.svg` | Mono logo — all Ironstone |
| `assets/logo-white.svg` | Reversed logo — white on dark backgrounds |

---

## Guidelines Cards

Specimen cards are in `guidelines/` — each tagged with `@dsCard` for the Design System tab. They show the tokens and patterns at a glance.

---

## Surfaces This System Covers
1. Marketing website (landing, about, services, trainers, contact)
2. Coach-facing dashboard (member roster, programming, notes)
3. Printed materials (programme cards, assessment write-ups, signage)
4. Email & lifecycle comms (welcome, session reminder, progress report)
5. Social media templates (Instagram post/story frames)
